package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews

private val ROW = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4, R.id.row5, R.id.row6, R.id.row7)
private val CK = intArrayOf(R.id.ck0, R.id.ck1, R.id.ck2, R.id.ck3, R.id.ck4, R.id.ck5, R.id.ck6, R.id.ck7)
private val TT = intArrayOf(R.id.tt0, R.id.tt1, R.id.tt2, R.id.tt3, R.id.tt4, R.id.tt5, R.id.tt6, R.id.tt7)
private val ST = intArrayOf(R.id.st0, R.id.st1, R.id.st2, R.id.st3, R.id.st4, R.id.st5, R.id.st6, R.id.st7)
private val DAYV = intArrayOf(R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6)

private val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
private val REGULAR: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)

class Row(val key: String, val title: String, val done: Boolean, val color: Int, val goal: String = "", val date: Int = 0)

class GoalsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACT) return
        val n = intent.getIntExtra("n", 0)
        val sel = Store.sel(context)
        when (intent.getStringExtra("a")) {
            "wk" -> Store.setSel(context, sel + 7 * n)
            "mo" -> Store.setSel(context, shiftMonth(sel, n))
            "day" -> Store.setSel(context, wsOf(sel) + n)
            "today" -> Store.setSel(context, todayDay())
            "view" -> Store.setView(context, if (Store.view(context) == n) 0 else n)
        }
        refresh(context)
    }

    companion object {
        const val ACT = "app.goals.ACT"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, GoalsWidget::class.java))) update(c, m, id)
        }

        private fun act(c: Context, a: String, n: Int): PendingIntent {
            val i = Intent(c, GoalsWidget::class.java)
            i.action = ACT
            i.data = Uri.parse("goals://act/" + a + "/" + n)
            i.putExtra("a", a)
            i.putExtra("n", n)
            return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun open(c: Context, cls: Class<*>, m: String): PendingIntent {
            val i = Intent(c, cls)
            i.data = Uri.parse("goals://open/" + cls.simpleName + "/" + Uri.encode(m))
            i.putExtra("m", m)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            Lang.load(c)
            val rtl = !Lang.en
            val o = mgr.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 320).coerceAtLeast(240)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 420).coerceAtLeast(240)
            val m = Model(c)
            val today = todayDay()
            val sel = Store.sel(c)
            val ws = wsOf(sel)
            val tr = Store.tr(c)
            val pal = PalGen.get(c, tr)
            val showDone = Store.opt(c, "showDone", false)
            val details = Store.opt(c, "details", false)
            val innerW = (wDp - 24) * d
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setInt(R.id.root, "setLayoutDirection", Lang.dir)
            rv.setInt(R.id.scrim, "setImageAlpha", ((100 - tr) * 0.8f * 2.55f).toInt())

            // الهيدر: سطر واحد "الشهر · الأسبوع"
            rv.setImageViewBitmap(R.id.ic_menu, dotsBmp((18 * d).toInt(), pal.muted))
            rv.setImageViewBitmap(R.id.ic_add, plusBmp((20 * d).toInt(), pal.fg))
            rv.setImageViewBitmap(R.id.ic_today, todayBmp((40 * d).toInt(), pal.muted, civil(today)[2]))
            rv.setImageViewBitmap(R.id.mo_prev, chevBmp((48 * d).toInt(), pal.muted, rtl))
            rv.setImageViewBitmap(R.id.mo_next, chevBmp((48 * d).toInt(), pal.muted, !rtl))
            val cs = civil(sel)
            val moTxt = MONTHS[cs[1] - 1] + (if (cs[0] != civil(today)[0]) " " + cs[0] else "")
            rv.setTextViewText(R.id.mo_lbl, moTxt)
            rv.setTextViewText(R.id.wk_lbl, "  ·  " + T("أسبوع ", "W") + weekNo(ws))
            rv.setTextColor(R.id.mo_lbl, pal.fg)
            rv.setTextColor(R.id.wk_lbl, pal.muted)
            rv.setOnClickPendingIntent(R.id.btn_menu, open(c, MenuActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.btn_add, open(c, AddActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.btn_today, act(c, "today", 0))
            rv.setOnClickPendingIntent(R.id.mo_prev, act(c, "wk", -1))
            rv.setOnClickPendingIntent(R.id.mo_next, act(c, "wk", 1))
            rv.setOnClickPendingIntent(R.id.mo_lbl, open(c, PickActivity::class.java, "month"))
            rv.setOnClickPendingIntent(R.id.wk_lbl, open(c, PickActivity::class.java, "week"))

            // الأهداف: دوائر تقدم
            val gb = drawRings(m, ws, innerW, d, pal, rtl)
            var goalsDp = 0f
            if (gb == null) {
                rv.setViewVisibility(R.id.goals_img, View.GONE)
            } else {
                rv.setViewVisibility(R.id.goals_img, View.VISIBLE)
                rv.setImageViewBitmap(R.id.goals_img, gb)
                rv.setOnClickPendingIntent(R.id.goals_img, open(c, GoalCardActivity::class.java, ""))
                goalsDp = gb.height / d
            }

            // أيام الأسبوع
            rv.setImageViewBitmap(R.id.week_img, drawWeek(m, ws, sel, today, innerW, d, pal, rtl))
            for (i in 0..6) rv.setOnClickPendingIntent(DAYV[i], act(c, "day", i))

            // شريط التقدم + المتراكمة
            val od = overdueRows(m, today, pal)
            val view = Store.view(c).let { if (it == 1 && od.isEmpty()) 0 else it }
            val dr = dayRows(m, sel, pal)
            val frac = if (dr.isEmpty()) 0f else dr.count { it.done }.toFloat() / dr.size
            rv.setImageViewBitmap(R.id.bar_img, drawTodayBar(frac, od.isNotEmpty(), view, innerW, d, pal, rtl))
            rv.setOnClickPendingIntent(R.id.z_dot, act(c, "view", 1))

            // المهام
            val all = when (view) {
                1 -> od
                2 -> listRows(m, pal)
                else -> dr
            }
            val rows = if (showDone) all else all.filter { !it.done }
            val avail = hDp - 24 - 36 - goalsDp - 50 - 20 - 6
            val cap = (avail / 30f).toInt().coerceIn(1, 8)
            val shown = if (rows.size > cap) cap - 1 else rows.size
            for (i in 0..7) {
                rv.setViewVisibility(ST[i], View.GONE)
                if (rows.isEmpty() && i == 0) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.GONE)
                    val msg = if (all.isNotEmpty()) T("كل المهام منجزة", "All done") else T("لا مهام", "No tasks")
                    rv.setTextViewText(TT[i], msg)
                    rv.setTextColor(TT[i], pal.muted)
                    rv.setOnClickPendingIntent(TT[i], open(c, AddActivity::class.java, ""))
                } else if (i < shown) {
                    val r = rows[i]
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.VISIBLE)
                    rv.setImageViewBitmap(CK[i], checkBmp((18 * d).toInt(), r.color, r.done))
                    val sp = SpannableString(r.title)
                    if (r.done) sp.setSpan(StrikethroughSpan(), 0, sp.length, 0)
                    rv.setTextViewText(TT[i], sp)
                    rv.setTextColor(TT[i], if (r.done) pal.muted else pal.fg)
                    // التفاصيل: الهدف · التاريخ — والمتراكمة تعرض تاريخها الأصلي دائمًا
                    val parts = ArrayList<String>()
                    if (details && r.goal.isNotEmpty()) parts.add(r.goal)
                    if ((details || view == 1) && r.date != 0) parts.add(shortDate(r.date))
                    if (parts.isNotEmpty()) {
                        rv.setViewVisibility(ST[i], View.VISIBLE)
                        rv.setTextViewText(ST[i], parts.joinToString(" · "))
                        rv.setTextColor(ST[i], if (view == 1 && !details) pal.warn else pal.muted)
                    }
                    rv.setOnClickPendingIntent(CK[i], open(c, CelebrateActivity::class.java, r.key))
                    rv.setOnClickPendingIntent(TT[i], open(c, EditActivity::class.java, r.key))
                    rv.setOnClickPendingIntent(ST[i], open(c, EditActivity::class.java, r.key))
                } else if (i == shown && rows.size > shown) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.GONE)
                    rv.setTextViewText(TT[i], "+" + (rows.size - shown))
                    rv.setTextColor(TT[i], pal.muted)
                    rv.setOnClickPendingIntent(TT[i], open(c, MainActivity::class.java, ""))
                } else {
                    rv.setViewVisibility(ROW[i], View.GONE)
                }
            }
            mgr.updateAppWidget(id, rv)
        }
    }
}

fun dayRows(m: Model, sel: Int, pal: Pal): List<Row> {
    val out = ArrayList<Row>()
    for (g in m.goals) for (t in g.tasks) if (t.date == sel) out.add(Row("g|" + g.id + "|" + t.id, t.title, t.done, PalGen.goalColor(m, pal, g), g.title, t.date))
    for (t in m.loose) if (t.date == sel) out.add(Row("l|" + t.id, t.title, t.done, PalGen.alpha(pal.fg, 200), "", t.date))
    return out
}

fun overdueRows(m: Model, today: Int, pal: Pal): List<Row> {
    val tmp = ArrayList<Row>()
    for (g in m.goals) for (t in g.tasks) if (t.date < today && !t.done) tmp.add(Row("g|" + g.id + "|" + t.id, t.title, false, PalGen.goalColor(m, pal, g), g.title, t.date))
    for (t in m.loose) if (t.date < today && !t.done) tmp.add(Row("l|" + t.id, t.title, false, PalGen.alpha(pal.fg, 200), "", t.date))
    return tmp.sortedBy { it.date }
}

fun listRows(m: Model, pal: Pal): List<Row> {
    val out = ArrayList<Row>()
    for (l in m.lists) for (i in l.items) out.add(Row("i|" + l.id + "|" + i.id, i.title, i.done, PalGen.tone(pal, l.id), l.title, 0))
    return out
}

// دوائر الأهداف: هدف عادي = دائرة، هدف طويل المدى = دائرة خارجية وبداخلها دوائر أهدافه الفرعية
private fun drawRings(m: Model, ws: Int, W: Float, d: Float, pal: Pal, rtl: Boolean): Bitmap? {
    fun inWeek(g: G) = g.e >= ws && g.s <= ws + 6
    val roots = ArrayList<G>()
    for (g in m.goals) {
        val par = m.byId[g.parent]
        if (g.long) {
            if (inWeek(g) || m.kids(g).any { inWeek(it) }) roots.add(g)
        } else if (par == null && inWeek(g)) roots.add(g)
    }
    if (roots.isEmpty()) return null
    val size = 30 * d
    val gap = 12 * d
    val H = size + 6 * d
    val maxN = ((W + gap) / (size + gap)).toInt().coerceAtLeast(1)
    val list = roots.sortedBy { it.s }.take(maxN)
    val bmp = Bitmap.createBitmap(W.toInt(), H.toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    fun ring(cx: Float, cy: Float, r: Float, sw: Float, color: Int, f: Float) {
        p.strokeWidth = sw
        p.color = PalGen.alpha(color, 55)
        cv.drawCircle(cx, cy, r, p)
        if (f > 0f) {
            p.color = color
            val rr = RectF(cx - r, cy - r, cx + r, cy + r)
            if (f >= 0.999f) cv.drawCircle(cx, cy, r, p) else cv.drawArc(rr, -90f, (if (rtl) -1 else 1) * 360f * f, false, p)
        }
    }
    val total = list.size * size + (list.size - 1) * gap
    val start = if (rtl) W else 0f
    val cy = H / 2
    for ((k, g) in list.withIndex()) {
        val off = k * (size + gap) + size / 2
        val cx = if (rtl) start - off else start + off
        val col = PalGen.goalColor(m, pal, g)
        val sw = 2.2f * d
        ring(cx, cy, size / 2 - sw, sw, col, m.prog(g))
        if (g.long) {
            val ks = m.kids(g).filter { inWeek(it) }.take(2)
            var r = size / 2 - sw - 5 * d
            for ((j, kg) in ks.withIndex()) {
                val kc = if (j == 0) PalGen.mix(col, if (pal.dark) Color.WHITE else Color.BLACK, 0.25f) else PalGen.mix(col, if (pal.dark) Color.BLACK else Color.WHITE, 0.25f)
                ring(cx, cy, r, 1.8f * d, kc, m.prog(kg))
                r -= 4.5f * d
            }
        } else {
            val pr = Math.round(m.prog(g) * 100)
            if (pr >= 100) {
                p.style = Paint.Style.FILL
                p.color = col
                cv.drawCircle(cx, cy, 2.5f * d, p)
                p.style = Paint.Style.STROKE
            }
        }
    }
    if (total < 0) return null
    return bmp
}

private fun drawWeek(m: Model, ws: Int, sel: Int, today: Int, W: Float, d: Float, pal: Pal, rtl: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(W.toInt(), (50 * d).toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val colW = W / 7
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.textAlign = Paint.Align.CENTER
    fun cx(i: Int): Float = if (rtl) W - (i + 0.5f) * colW else (i + 0.5f) * colW
    val has = HashSet<Int>()
    for (g in m.goals) if (!g.long) for (t in g.tasks) has.add(t.date)
    for (t in m.loose) has.add(t.date)
    for (i in 0..6) {
        val day = ws + i
        val cy = 29 * d
        p.style = Paint.Style.FILL
        p.typeface = REGULAR
        p.textSize = 10 * d
        p.color = pal.muted
        cv.drawText(DAYS[i], cx(i), 10 * d, p)
        if (day == sel) {
            p.color = pal.accent
            cv.drawCircle(cx(i), cy, 13 * d, p)
        } else if (day == today) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            p.color = pal.accent
            cv.drawCircle(cx(i), cy, 12.5f * d, p)
            p.style = Paint.Style.FILL
        }
        p.typeface = MEDIUM
        p.textSize = 13.5f * d
        p.color = if (day == sel) (if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE) else pal.fg
        cv.drawText(civil(day)[2].toString(), cx(i), cy + 4.8f * d, p)
        if (has.contains(day) && day != sel) {
            p.color = pal.muted
            cv.drawCircle(cx(i), 47 * d, 1.6f * d, p)
        }
    }
    return bmp
}

private fun drawTodayBar(frac: Float, hasOd: Boolean, view: Int, W: Float, d: Float, pal: Pal, rtl: Boolean): Bitmap {
    val H = 20 * d
    val bmp = Bitmap.createBitmap(W.toInt(), H.toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val z = 28 * d
    val cy = H / 2
    // نقطة المتراكمة في نهاية السطر
    val dotX = if (rtl) z / 2 else W - z / 2
    if (hasOd) {
        p.style = Paint.Style.FILL
        p.color = pal.warn
        cv.drawCircle(dotX, cy, 3.5f * d, p)
        if (view == 1) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            cv.drawCircle(dotX, cy, 7f * d, p)
        }
    }
    val l = if (rtl && hasOd) z else 0f
    val r = if (!rtl && hasOd) W - z else W
    val t = 0.75f * d
    p.style = Paint.Style.FILL
    p.color = PalGen.alpha(pal.fg, 40)
    cv.drawRoundRect(RectF(l, cy - t, r, cy + t), t, t, p)
    p.color = pal.accent
    val fw = frac * (r - l)
    if (rtl) cv.drawRoundRect(RectF(r - fw, cy - t, r, cy + t), t, t, p)
    else cv.drawRoundRect(RectF(l, cy - t, l + fw, cy + t), t, t, p)
    return bmp
}

private fun chevBmp(sz: Int, color: Int, right: Boolean): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeJoin = Paint.Join.ROUND
    p.strokeWidth = sz * 0.06f
    val c = sz / 2f
    val s = if (right) 1f else -1f
    val path = Path()
    path.moveTo(c - s * sz * 0.14f, c - sz * 0.26f)
    path.lineTo(c + s * sz * 0.14f, c)
    path.lineTo(c - s * sz * 0.14f, c + sz * 0.26f)
    cv.drawPath(path, p)
    return b
}

private fun todayBmp(sz: Int, color: Int, day: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = sz * 0.065f
    cv.drawRoundRect(RectF(sz * 0.1f, sz * 0.16f, sz * 0.9f, sz * 0.9f), sz * 0.2f, sz * 0.2f, p)
    cv.drawLine(sz * 0.32f, sz * 0.05f, sz * 0.32f, sz * 0.24f, p)
    cv.drawLine(sz * 0.68f, sz * 0.05f, sz * 0.68f, sz * 0.24f, p)
    p.style = Paint.Style.FILL
    p.textAlign = Paint.Align.CENTER
    p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    p.textSize = sz * 0.42f
    cv.drawText(day.toString(), sz / 2f, sz * 0.7f, p)
    return b
}

private fun dotsBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    for (k in -1..1) cv.drawCircle(sz / 2f, sz / 2f + k * sz * 0.28f, sz * 0.09f, p)
    return b
}

private fun plusBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = sz * 0.06f
    val c = sz / 2f
    val r = sz * 0.34f
    cv.drawLine(c - r, c, c + r, c, p)
    cv.drawLine(c, c - r, c, c + r, p)
    return b
}

private fun checkBmp(sz: Int, color: Int, done: Boolean): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = sz / 2f
    val r = sz * 0.36f
    p.color = color
    if (done) {
        cv.drawCircle(c, c, r, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        val ck = Path()
        ck.moveTo(c - sz * 0.15f, c)
        ck.lineTo(c - sz * 0.04f, c + sz * 0.11f)
        ck.lineTo(c + sz * 0.16f, c - sz * 0.1f)
        cv.drawPath(ck, p)
    } else {
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.06f
        cv.drawCircle(c, c, r, p)
    }
    return b
}
