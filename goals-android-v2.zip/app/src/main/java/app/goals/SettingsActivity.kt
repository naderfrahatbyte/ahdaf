package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        fun dp(v: Int): Int = Ui.dp(this, v)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(18), dp(20), dp(16))
        root.addView(Ui.tv(this, T("الإعدادات", "Settings"), 20f, pal.fg, true))

        val lbl = Ui.tv(this, T("شفافية الودجت: ", "Widget transparency: ") + Store.tr(this) + "%", 15f, pal.fg)
        root.addView(lbl, Ui.lp(Ui.MP, Ui.WC, dp(16)))
        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = Store.tr(this)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                lbl.text = T("شفافية الودجت: ", "Widget transparency: ") + progress + "%"
                Store.setTr(this@SettingsActivity, progress)
                GoalsWidget.refresh(this@SettingsActivity)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(bar, Ui.lp(Ui.MP, Ui.WC))

        fun sw(t: String, key: String) {
            val s = Switch(this)
            s.text = t
            s.textSize = 15f
            s.setTextColor(pal.fg)
            s.isChecked = Store.flag(this, key)
            s.setOnCheckedChangeListener { _: CompoundButton, on: Boolean -> Store.setFlag(this, key, on) }
            root.addView(s, Ui.lp(Ui.MP, Ui.WC, dp(14)))
        }
        sw(T("الأصوات", "Sounds"), "snd")
        sw(T("الاحتفالات المتحركة", "Celebration animations"), "anim")

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ex = Ui.btn(this, T("نسخ احتياطي", "Back up"), PalGen.alpha(pal.fg, 28), pal.fg)
        val im = Ui.btn(this, T("استيراد", "Import"), PalGen.alpha(pal.fg, 28), pal.fg)
        ex.setOnClickListener { Backup.export(this) }
        im.setOnClickListener { Backup.importFile(this) }
        val l1 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        l1.setMargins(0, 0, dp(8), 0)
        row.addView(ex, l1)
        row.addView(im, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        root.addView(row, Ui.lp(Ui.MP, Ui.WC, dp(18)))

        val ok = Ui.btn(this, T("تم", "Done"), pal.accent, if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE)
        ok.setOnClickListener { finish() }
        root.addView(ok, Ui.lp(Ui.MP, Ui.WC, dp(12)))

        setContentView(root)
        Glass.apply(this, pal)
        window.setGravity(Gravity.BOTTOM)
        window.setDimAmount(0f)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}
