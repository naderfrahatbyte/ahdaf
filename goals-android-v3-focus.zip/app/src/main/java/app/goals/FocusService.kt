package app.goals

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

/**
 * Minimal AccessibilityService for Focus: when balance is depleted and the
 * foreground app is in the consume list, press HOME to leave it.
 * User must enable the service in system Accessibility settings.
 */
class FocusService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastPkg = ""
    private var lastCheck = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == lastPkg) return
        val now = System.currentTimeMillis()
        if (now - lastCheck < 400) return
        lastCheck = now
        lastPkg = pkg
        handler.post { maybeBlock(pkg) }
    }

    private fun maybeBlock(pkg: String) {
        try {
            val raw = getSharedPreferences("g", 0).getString("d", "") ?: return
            val root = JSONObject(raw)
            val focus = root.optJSONObject("focus") ?: return
            val balance = focus.optDouble("balance", 0.0)
            if (balance > 0.01) return
            val consume = focus.optJSONArray("consume") ?: return
            for (i in 0 until consume.length()) {
                val o = consume.optJSONObject(i) ?: continue
                if (o.optString("pkg") == pkg) {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    return
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {}

    companion object {
        fun isEnabled(ctx: android.content.Context): Boolean {
            val am = ctx.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
            val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            val me = ctx.packageName + "/" + FocusService::class.java.name
            return list.any { it.id == me || it.id.endsWith("/.FocusService") || it.id.endsWith("/FocusService") }
        }
    }
}
