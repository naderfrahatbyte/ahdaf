package app.goals

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Usage-stats helpers for Focus: check permission, list launchable apps,
 * query foreground minutes since a timestamp, and apply earn/spend deltas
 * without double-counting (lastProcess stored in focus JSON).
 */
object FocusUsage {

    fun hasPermission(c: Context): Boolean {
        return try {
            val appOps = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), c.packageName)
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), c.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    fun openUsageSettings(c: Context) {
        c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openAccessibilitySettings(c: Context) {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun listApps(c: Context): String {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            if (pkg == c.packageName || !seen.add(pkg)) continue
            val label = try {
                ri.loadLabel(pm).toString()
            } catch (_: Exception) {
                pkg
            }
            arr.put(JSONObject().put("pkg", pkg).put("name", label))
        }
        // sort by name
        val list = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
        list.sortBy { it.optString("name").lowercase() }
        val out = JSONArray()
        list.forEach { out.put(it) }
        return out.toString()
    }

    /** Minutes of foreground usage for each package between [fromMs, toMs]. */
    fun queryMinutes(c: Context, pkgs: Collection<String>, fromMs: Long, toMs: Long): Map<String, Double> {
        if (!hasPermission(c) || pkgs.isEmpty() || toMs <= fromMs) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, fromMs, toMs) ?: return emptyMap()
        val want = pkgs.toHashSet()
        val result = HashMap<String, Double>()
        for (s in stats) {
            if (s.packageName !in want) continue
            val ms = s.totalTimeInForeground
            if (ms > 0) result[s.packageName] = (result[s.packageName] ?: 0.0) + ms / 60000.0
        }
        return result
    }

    /**
     * Apply usage since lastProcess: earn from productive (rate per min),
     * spend from consume (cost per min). Balance never goes negative.
     * Returns updated focus JSON object as string (or empty if nothing changed).
     */
    fun process(c: Context): String {
        if (!hasPermission(c)) return ""
        val pref = c.getSharedPreferences("g", 0)
        val raw = pref.getString("d", "") ?: return ""
        val root = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return ""
        }
        val focus = root.optJSONObject("focus") ?: JSONObject().also { root.put("focus", it) }
        ensureFocus(focus)
        val now = System.currentTimeMillis()
        var last = focus.optLong("lastProcess", 0L)
        if (last <= 0L) {
            // first run: only set baseline, no credit yet
            focus.put("lastProcess", now)
            pref.edit().putString("d", root.toString()).apply()
            return focus.toString()
        }
        // cap lookback to 6 hours to avoid huge jumps after long absence
        if (now - last > 6 * 3600_000L) last = now - 6 * 3600_000L

        val prodPkgs = mutableListOf<String>()
        val prodRates = HashMap<String, Double>()
        val productive = focus.optJSONArray("productive") ?: JSONArray()
        for (i in 0 until productive.length()) {
            val o = productive.optJSONObject(i) ?: continue
            val pkg = o.optString("pkg")
            if (pkg.isEmpty()) continue
            prodPkgs.add(pkg)
            prodRates[pkg] = o.optDouble("rate", 1.0)
        }
        val consPkgs = mutableListOf<String>()
        val consCosts = HashMap<String, Double>()
        val consume = focus.optJSONArray("consume") ?: JSONArray()
        for (i in 0 until consume.length()) {
            val o = consume.optJSONObject(i) ?: continue
            val pkg = o.optString("pkg")
            if (pkg.isEmpty()) continue
            consPkgs.add(pkg)
            consCosts[pkg] = o.optDouble("cost", 1.0)
        }
        val all = (prodPkgs + consPkgs).toSet()
        if (all.isEmpty()) {
            focus.put("lastProcess", now)
            pref.edit().putString("d", root.toString()).apply()
            return focus.toString()
        }

        val minutes = queryMinutes(c, all, last, now)
        var balance = focus.optDouble("balance", 0.0)
        val log = focus.optJSONArray("log") ?: JSONArray().also { focus.put("log", it) }
        var changed = false

        for ((pkg, mins) in minutes) {
            if (mins < 0.05) continue
            val rounded = (mins * 10).toInt() / 10.0 // 0.1 min precision
            if (rounded < 0.1) continue
            if (pkg in prodRates) {
                val gain = rounded * (prodRates[pkg] ?: 1.0)
                balance += gain
                prependLog(log, "earn", pkg, rounded, gain, now)
                changed = true
            }
            if (pkg in consCosts) {
                val cost = rounded * (consCosts[pkg] ?: 1.0)
                val actual = minOf(cost, balance)
                if (actual > 0.001) {
                    balance -= actual
                    prependLog(log, "spend", pkg, rounded, -actual, now)
                    changed = true
                }
            }
        }

        // habits with per_minute: same logic if they have a pkg
        val habits = focus.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until habits.length()) {
            val h = habits.optJSONObject(i) ?: continue
            if (h.optString("reward") != "per_minute") continue
            val pkg = h.optString("pkg")
            if (pkg.isEmpty()) continue
            val mins = minutes[pkg] ?: continue
            val rounded = (mins * 10).toInt() / 10.0
            if (rounded < 0.1) continue
            val rate = h.optDouble("amount", 1.0)
            val gain = rounded * rate
            balance += gain
            prependLog(log, "habit", h.optString("title", pkg), rounded, gain, now)
            changed = true
        }

        focus.put("balance", maxOf(0.0, (balance * 100).toInt() / 100.0))
        focus.put("lastProcess", now)
        // keep log short
        while (log.length() > 40) log.remove(log.length() - 1)
        pref.edit().putString("d", root.toString()).apply()
        return if (changed) focus.toString() else focus.toString()
    }

    private fun prependLog(log: JSONArray, type: String, label: String, mins: Double, delta: Double, ts: Long) {
        val o = JSONObject()
            .put("t", type)
            .put("label", label)
            .put("mins", mins)
            .put("delta", (delta * 100).toInt() / 100.0)
            .put("ts", ts)
        // insert at 0
        val copy = JSONArray()
        copy.put(o)
        for (i in 0 until log.length()) copy.put(log.get(i))
        // replace contents
        while (log.length() > 0) log.remove(0)
        for (i in 0 until copy.length()) log.put(copy.get(i))
    }

    fun ensureFocus(focus: JSONObject) {
        if (!focus.has("balance")) focus.put("balance", 0.0)
        if (!focus.has("productive")) focus.put("productive", JSONArray())
        if (!focus.has("habits")) focus.put("habits", JSONArray())
        if (!focus.has("consume")) focus.put("consume", JSONArray())
        if (!focus.has("log")) focus.put("log", JSONArray())
        if (!focus.has("lastProcess")) focus.put("lastProcess", 0L)
    }
}
