package app.goals

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private var web: WebView? = null
    private var started = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#150e1f")
        window.navigationBarColor = Color.parseColor("#150e1f")
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#150e1f") )
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(this), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    return true
                }
                return false
            }
        }
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
        web = w
    }

    override fun onResume() {
        super.onResume()
        try {
            FocusUsage.process(this)
        } catch (_: Exception) {
        }
        if (started) web?.reload()
        started = true
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}

class Bridge(private val a: MainActivity) {
    private val c: Context = a

    @JavascriptInterface
    fun load(): String = c.getSharedPreferences("g", 0).getString("d", "") ?: ""

    @JavascriptInterface
    fun save(s: String) {
        c.getSharedPreferences("g", 0).edit().putString("d", s).apply()
        GoalsWidget.refresh(c)
    }

    @JavascriptInterface
    fun exportBackup() {
        a.runOnUiThread { Backup.export(a) }
    }

    @JavascriptInterface
    fun importBackup() {
        a.runOnUiThread { Backup.importFile(a) }
    }

    @JavascriptInterface
    fun getPref(k: String): Int = if (Store.flag(c, k)) 1 else 0

    @JavascriptInterface
    fun setPref(k: String, v: Int) {
        Store.setFlag(c, k, v != 0)
    }

    @JavascriptInterface
    fun focusHasUsage(): Int = if (FocusUsage.hasPermission(c)) 1 else 0

    @JavascriptInterface
    fun focusOpenUsageSettings() {
        a.runOnUiThread { FocusUsage.openUsageSettings(a) }
    }

    @JavascriptInterface
    fun focusHasA11y(): Int = if (FocusService.isEnabled(c)) 1 else 0

    @JavascriptInterface
    fun focusOpenA11ySettings() {
        a.runOnUiThread { FocusUsage.openAccessibilitySettings(a) }
    }

    @JavascriptInterface
    fun focusListApps(): String = try {
        FocusUsage.listApps(c)
    } catch (_: Exception) {
        "[]"
    }

    @JavascriptInterface
    fun focusProcess(): String = try {
        FocusUsage.process(c)
    } catch (_: Exception) {
        ""
    }
}
