package app.goals

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

// إعدادات المهمة: تعديل الاسم والوصف والتاريخ أو حذفها
class EditActivity : Activity() {
    private var date = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val key = intent.getStringExtra("m") ?: ""
        val t = Store.task(this, key)
        if (t == null) {
            finish()
            return
        }
        val pal = PalGen.get(this, 85)
        val m = Model(this)
        val isItem = key.startsWith("i|")
        fun dp(v: Int): Int = Ui.dp(this, v)
        date = try { days(t.getString("date")) } catch (e: Exception) { todayDay() }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(20), dp(18), dp(20), dp(16))

        val parts = key.split("|")
        val owner = when (parts[0]) {
            "g" -> m.byId[parts[1]]?.title ?: ""
            "i" -> m.lists.firstOrNull { it.id == parts[1] }?.title ?: ""
            else -> ""
        }
        if (owner.isNotEmpty()) root.addView(Ui.tv(this, owner, 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC))

        val title = EditText(this)
        title.setText(t.optString("title"))
        title.textSize = 18f
        title.setTextColor(pal.fg)
        title.setBackgroundColor(Color.TRANSPARENT)
        title.setSingleLine(true)
        title.setPadding(0, dp(4), 0, dp(4))
        title.setSelection(title.text.length)
        root.addView(title, Ui.lp(Ui.MP, Ui.WC))

        val desc = EditText(this)
        desc.setText(t.optString("desc"))
        desc.hint = T("وصف", "Description")
        desc.textSize = 13f
        desc.setTextColor(pal.fg)
        desc.setHintTextColor(pal.muted)
        desc.setBackgroundColor(Color.TRANSPARENT)
        desc.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        desc.minLines = 2
        desc.gravity = Gravity.TOP or Gravity.START
        desc.setPadding(0, dp(4), 0, dp(8))
        if (isItem) desc.visibility = View.GONE
        root.addView(desc, Ui.lp(Ui.MP, Ui.WC))

        val dateChip = Ui.chip(this, shortDate(date), pal, true)
        dateChip.setOnClickListener {
            val c = civil(date)
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, y, mo, dd ->
                date = ymd(y, mo + 1, dd)
                dateChip.text = shortDate(date)
            }, c[0], c[1] - 1, c[2]).show()
        }
        val dateRow = LinearLayout(this)
        dateRow.orientation = LinearLayout.HORIZONTAL
        dateRow.addView(dateChip, Ui.lp(Ui.WC, Ui.WC))
        if (isItem) dateRow.visibility = View.GONE
        root.addView(dateRow, Ui.lp(Ui.MP, Ui.WC, dp(6)))

        val save = Ui.btn(this, T("حفظ", "Save"), pal.accent, if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE)
        val del = Ui.btn(this, T("حذف", "Delete"), Color.TRANSPARENT, pal.warn)
        val cancel = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        save.setOnClickListener {
            val nt = title.text.toString().trim()
            if (nt.isEmpty()) {
                Toast.makeText(this, T("اكتب المهمة أولًا", "Type a task first"), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val ok = Store.update(this, key, nt, desc.text.toString().trim(), date)
            if (!ok) Toast.makeText(this, T("تم ضبط اليوم داخل مدى الهدف", "Date moved inside the goal range"), Toast.LENGTH_SHORT).show()
            GoalsWidget.refresh(this)
            finish()
        }
        var armed = false
        del.setOnClickListener {
            if (!armed) {
                armed = true
                del.text = T("تأكيد الحذف", "Confirm delete")
                return@setOnClickListener
            }
            Store.delete(this, key)
            GoalsWidget.refresh(this)
            finish()
        }
        cancel.setOnClickListener { finish() }
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        // ثلاثة أزرار متساوية العرض وسطر واحد، حتى لا تنكسر كلمة مثل Cancel
        for (b in listOf(save, del, cancel)) {
            b.textSize = 15f
            b.maxLines = 1
            b.setPadding(dp(6), dp(12), dp(6), dp(12))
        }
        val lpSave = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        lpSave.marginEnd = dp(6)
        val lpDel = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        lpDel.marginEnd = dp(6)
        btns.addView(save, lpSave)
        btns.addView(del, lpDel)
        btns.addView(cancel, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        root.addView(btns, Ui.lp(Ui.MP, Ui.WC, dp(14)))

        setContentView(root)
        Glass.apply(this, pal)
        window.setGravity(Gravity.TOP)
        val lp = window.attributes
        lp.y = dp(40)
        window.attributes = lp
    }
}
