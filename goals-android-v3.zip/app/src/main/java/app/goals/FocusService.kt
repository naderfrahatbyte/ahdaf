package app.goals

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

// مراقبة التطبيق المفتوح (في الواجهة فقط) لاحتساب الرصيد، وحظر التطبيقات المستهلكة عند نفاده.
// تعتمد على خدمة إمكانية الوصول: لا تقرأ محتوى الشاشة، وتستخدم اسم حزمة النافذة الأمامية فقط.
class FocusService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var cur = ""
    private var last = 0L
    private var lastBlock = 0L
    private var n = 0
    private val ignore = HashSet<String>()
    private val tick = object : Runnable {
        override fun run() {
            step()
            h.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        FocusStore.init(this)
        refreshIgnore()
        last = SystemClock.elapsedRealtime()
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun refreshIgnore() {
        ignore.clear()
        ignore.add("com.android.systemui")
        ignore.add("android")
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (i in im.enabledInputMethodList) ignore.add(i.packageName)
        } catch (e: Exception) {
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p in ignore) return
        if (p != cur) {
            cur = p
            // فتح تطبيق مستهلك والرصيد صفر: حظر فوري
            if (FocusStore.spendApp(cur) != null && FocusStore.earnApp(cur) == null && FocusStore.bal <= 0.0) block()
        }
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - last
        last = now
        if (++n % 60 == 0) refreshIgnore()
        FocusStore.save()
        if (cur.isEmpty()) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        // لا احتساب والشاشة مطفأة أو مقفلة (منع احتساب الخلفية)
        if (!pm.isInteractive || km.isKeyguardLocked) return
        // سقف للفارق الزمني حتى لا يُحتسب الوقت مرتين أو دفعة واحدة بعد تعليق النظام
        val sec = dt.coerceIn(0L, 2500L) / 1000.0
        val e = FocusStore.earnApp(cur)
        if (e != null) {
            FocusStore.add(e.rate * sec / 60.0, e.name, "e:" + cur, true)
            return
        }
        val s = FocusStore.spendApp(cur) ?: return
        if (FocusStore.bal <= 0.0) {
            block()
            return
        }
        FocusStore.add(-s.rate * sec / 60.0, s.name, "s:" + cur, true)
        if (FocusStore.bal <= 0.0) block()
    }

    private fun block() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 2500) return
        lastBlock = now
        cur = ""
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            val i = Intent(this, FocusBlockActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacks(tick)
        FocusStore.save(true)
        super.onDestroy()
    }

    companion object {
        fun enabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, FocusService::class.java)
            for (x in s.split(':')) {
                val cn = ComponentName.unflattenFromString(x) ?: continue
                if (cn == me) return true
            }
            return false
        }
    }
}
