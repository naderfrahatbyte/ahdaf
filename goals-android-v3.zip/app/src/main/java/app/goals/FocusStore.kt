package app.goals

import android.content.Context
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// تطبيق منتج/مستهلك مع معدّل الدقيقة (rate)
class FApp(val pkg: String, var name: String, var rate: Double)

// عادة: kind 0 = مكافأة يدوية، 1 = لكل دقيقة، 2 = مكافأة ثابتة
class FHabit(val id: String, var title: String, var kind: Int, var value: Double)

class FLog(var ts: Long, var delta: Double, val label: String, val ref: String)

// بيانات Focus محلية في SharedPreferences منفصلة ("focus") دون المساس ببيانات الأهداف
object FocusStore {
    private var ctx: Context? = null
    var bal = 0.0
    val earn = ArrayList<FApp>()
    val spend = ArrayList<FApp>()
    val habits = ArrayList<FHabit>()
    val log = ArrayList<FLog>()
    private var dirty = false
    private var lastSave = 0L

    fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        try {
            val raw = ctx!!.getSharedPreferences("focus", 0).getString("d", "") ?: ""
            if (raw.isNotEmpty()) fromJson(JSONObject(raw))
        } catch (e: Exception) {
        }
    }

    private fun fromJson(o: JSONObject) {
        bal = o.optDouble("bal", 0.0).coerceAtLeast(0.0)
        earn.clear()
        spend.clear()
        habits.clear()
        log.clear()
        val ea = o.optJSONArray("earn") ?: JSONArray()
        for (i in 0 until ea.length()) {
            val x = ea.getJSONObject(i)
            earn.add(FApp(x.getString("p"), x.optString("n"), x.optDouble("r", 1.0)))
        }
        val sa = o.optJSONArray("spend") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val x = sa.getJSONObject(i)
            spend.add(FApp(x.getString("p"), x.optString("n"), x.optDouble("r", 1.0)))
        }
        val ha = o.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until ha.length()) {
            val x = ha.getJSONObject(i)
            habits.add(FHabit(x.getString("id"), x.optString("t"), x.optInt("k", 2), x.optDouble("v", 1.0)))
        }
        val la = o.optJSONArray("log") ?: JSONArray()
        for (i in 0 until la.length()) {
            val x = la.getJSONObject(i)
            log.add(FLog(x.optLong("ts"), x.optDouble("d", 0.0), x.optString("l"), x.optString("r")))
        }
    }

    private fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("bal", bal)
        val ea = JSONArray()
        for (a in earn) ea.put(JSONObject().put("p", a.pkg).put("n", a.name).put("r", a.rate))
        o.put("earn", ea)
        val sa = JSONArray()
        for (a in spend) sa.put(JSONObject().put("p", a.pkg).put("n", a.name).put("r", a.rate))
        o.put("spend", sa)
        val ha = JSONArray()
        for (h in habits) ha.put(JSONObject().put("id", h.id).put("t", h.title).put("k", h.kind).put("v", h.value))
        o.put("habits", ha)
        val la = JSONArray()
        for (l in log) la.put(JSONObject().put("ts", l.ts).put("d", l.delta).put("l", l.label).put("r", l.ref))
        o.put("log", la)
        return o
    }

    // للنسخ الاحتياطي والاستعادة
    fun snapshot(c: Context): JSONObject {
        init(c)
        return toJson()
    }

    fun restore(c: Context, o: JSONObject) {
        init(c)
        try {
            fromJson(o)
            dirty = true
            save(true)
        } catch (e: Exception) {
        }
    }

    fun save(force: Boolean = false) {
        val c = ctx ?: return
        if (!force) {
            if (!dirty) return
            if (SystemClock.elapsedRealtime() - lastSave < 5000) return
        }
        c.getSharedPreferences("focus", 0).edit().putString("d", toJson().toString()).apply()
        dirty = false
        lastSave = SystemClock.elapsedRealtime()
    }

    fun earnApp(pkg: String): FApp? = earn.firstOrNull { it.pkg == pkg }
    fun spendApp(pkg: String): FApp? = spend.firstOrNull { it.pkg == pkg }

    // يضيف/يخصم من الرصيد المشترك؛ لا يصبح الرصيد سالبًا أبدًا. يعيد المقدار المطبّق فعلًا.
    fun add(delta: Double, label: String, ref: String, merge: Boolean): Double {
        val nb = (bal + delta).coerceAtLeast(0.0)
        val applied = nb - bal
        if (Math.abs(applied) < 1e-9) return 0.0
        bal = nb
        val now = System.currentTimeMillis()
        val top = log.firstOrNull()
        if (merge && top != null && top.ref == ref && now - top.ts < 600000L) {
            top.delta += applied
            top.ts = now
        } else {
            log.add(0, FLog(now, applied, label, ref))
            while (log.size > 60) log.removeAt(log.size - 1)
        }
        dirty = true
        save(!merge)
        return applied
    }

    fun fmt(x: Double): String {
        val r = Math.round(x * 10) / 10.0
        return if (r == Math.floor(r)) r.toLong().toString() else String.format(Locale.US, "%.1f", r)
    }

    fun fmtFloor(x: Double): String = fmt(Math.floor(x * 10) / 10.0)
}
