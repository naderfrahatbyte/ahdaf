package app.goals

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.content.ComponentName
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

private class PApp(val pkg: String, val name: String, val icon: Drawable?)

// قسم Focus: الرصيد، التطبيقات المنتجة، العادات، التطبيقات المستهلكة، وسجل الرصيد
class FocusActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var pageScroll: ScrollView
    private lateinit var pal: Pal
    private var logShown = 30
    private val anchors = linkedMapOf<String, View>()

    private fun dp(v: Int): Int = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        FocusStore.init(this)
        pal = PalGen.get(this, 85)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = Lang.dir
        box.setPadding(dp(18), dp(16), dp(18), dp(16))
        pageScroll = ScrollView(this)
        pageScroll.isFillViewport = true
        pageScroll.addView(box)
        setContentView(pageScroll)
        Glass.apply(this, pal, 0.96f)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun onAccent(): Int = if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE

    private fun num(s: String): Double? {
        val sb = StringBuilder()
        for (ch in s.trim()) {
            when {
                ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                ch == '٫' || ch == '،' || ch == ',' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString().toDoubleOrNull()
    }

    private fun icon(pkg: String): Drawable? = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }

    private fun section(title: String, sub: String, key: String? = null) {
        val heading = Ui.tv(this, title, 16f, pal.fg, true)
        box.addView(heading, Ui.lp(Ui.MP, Ui.WC, dp(22)))
        if (key != null) anchors[key] = heading
        if (sub.isNotBlank()) box.addView(Ui.tv(this, sub, 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(2)))
    }

    private fun scrollShortcuts() {
        val horizontal = android.widget.HorizontalScrollView(this)
        horizontal.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val entries = listOf(
            "habits" to T("العادات", "Habits"),
            "earn" to T("تطبيقات تكسب", "Earn apps"),
            "spend" to T("تطبيقات تستهلك", "Limit apps"),
            "history" to T("السجل", "History")
        )
        for ((key, label) in entries) {
            val chip = Ui.chip(this, label, pal, false)
            chip.setOnClickListener {
                val target = anchors[key]
                if (target != null) pageScroll.post { pageScroll.smoothScrollTo(0, target.top) }
            }
            val lp = LinearLayout.LayoutParams(Ui.WC, Ui.WC)
            lp.marginEnd = dp(7)
            row.addView(chip, lp)
        }
        horizontal.addView(row)
        box.addView(horizontal, Ui.lp(Ui.MP, Ui.WC, dp(12)))
    }

    private fun quickActions() {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val actions: List<Triple<String, Int, () -> Unit>> = listOf(
            Triple(T("+ عادة", "+ Habit"), pal.accent, { habitDialog(null) }),
            Triple(T("+ تطبيق منتج", "+ Earn app"), PalGen.alpha(pal.accent, 38), { pickApp(true) }),
            Triple(T("+ تطبيق محدود", "+ Limit app"), PalGen.alpha(pal.warn, 38), { pickApp(false) })
        )
        for ((label, bg, action) in actions) {
            val b = Ui.btn(this, label, bg, if (bg == pal.accent) onAccent() else pal.fg)
            b.textSize = 12f
            b.setPadding(dp(7), dp(12), dp(7), dp(12))
            b.setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(0, Ui.WC, 1f)
            lp.marginEnd = dp(6)
            row.addView(b, lp)
        }
        box.addView(row, Ui.lp(Ui.MP, Ui.WC, dp(12)))
    }

    private fun emptyHint(message: String) {
        val hint = Ui.tv(this, message, 12f, pal.muted)
        hint.setPadding(dp(12), dp(10), dp(12), dp(10))
        hint.background = Ui.shape(PalGen.alpha(pal.fg, 12), pal.line, dp(12).toFloat(), dp(1))
        box.addView(hint, Ui.lp(Ui.MP, Ui.WC, dp(8)))
    }

    // أزرار ضمان العمل المستمر: البطارية + التشغيل التلقائي (شاومي)
    private fun keepAlive(w: LinearLayout) {
        val bt = Ui.btn(this, T("إعدادات البطارية", "Battery settings"), Color.TRANSPARENT, pal.muted)
        bt.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:" + packageName)
                startActivity(i)
            }
        }
        w.addView(bt, Ui.lp(Ui.MP, Ui.WC, dp(2)))
        val au = Ui.btn(this, T("التشغيل التلقائي", "Autostart"), Color.TRANSPARENT, pal.muted)
        au.setOnClickListener {
            try {
                val i = Intent()
                i.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                startActivity(i)
            } catch (e: Exception) {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:" + packageName)
                startActivity(i)
            }
        }
        w.addView(au, Ui.lp(Ui.MP, Ui.WC, dp(2)))
    }

    private fun fmtDur(sec: Double): String {
        val s = sec.toInt()
        return if (s < 60) s.toString() + T(" ث", " s") else (s / 60).toString() + T(" د", " min")
    }

    private fun addRow(t: String, f: () -> Unit) {
        val v = Ui.tv(this, t, 14f, pal.accent, true)
        v.setPadding(0, dp(12), 0, dp(6))
        v.setOnClickListener { f() }
        box.addView(v, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun sep() {
        val v = View(this)
        v.setBackgroundColor(PalGen.alpha(pal.fg, 30))
        box.addView(v, Ui.lp(Ui.MP, 1))
    }

    private fun render() {
        box.removeAllViews()
        anchors.clear()
        box.addView(Ui.tv(this, "Focus", 25f, pal.fg, true))
        box.addView(Ui.tv(this, T("حوّل وقتك إلى رصيد، واستخدمه بوعي.", "Turn your time into credit, then spend it intentionally."), 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(3)))
        quickActions()
        scrollShortcuts()

        // الرصيد الحالي
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(12), dp(16), dp(14))
        card.background = Ui.shape(PalGen.alpha(pal.accent, 40), 0, dp(20).toFloat())
        card.addView(Ui.tv(this, T("رصيدك المشترك", "Your shared credit balance"), 13f, pal.muted))
        card.addView(Ui.tv(this, FocusStore.fmtFloor(FocusStore.bal), 44f, pal.fg, true))
        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.addView(Ui.tv(this, T("اليوم  ", "Today  ") + "+" + FocusStore.fmt(FocusStore.earnedNow()), 13f, pal.accent, true))
        val st2 = Ui.tv(this, "−" + FocusStore.fmt(FocusStore.spentNow()), 13f, pal.warn, true)
        st2.setPadding(dp(14), 0, 0, 0)
        stats.addView(st2)
        card.addView(stats, Ui.lp(Ui.MP, Ui.WC, dp(2)))
        card.addView(Ui.tv(this, T("تكسب من العادات والمهام ذات المكافأة والتطبيقات المنتجة؛ وتُنفق عند استخدام التطبيقات المحددة أدناه.", "Earn from habits, rewarded tasks and productive apps; spend credit on the limited apps below."), 12f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(8)))
        // الحد اليومي للمكافآت
        val capTxt = if (FocusStore.cap > 0.0) T("الحد اليومي للمكافآت: ", "Daily reward cap: ") + FocusStore.fmt(FocusStore.earnedNow()) + " / " + FocusStore.fmt(FocusStore.cap)
        else T("الحد اليومي للمكافآت: بلا حد", "Daily reward cap: none")
        val capV = Ui.tv(this, capTxt + "  ✎", 12f, pal.muted)
        capV.setPadding(0, dp(10), 0, dp(4))
        capV.setOnClickListener {
            askNumber(T("الحد اليومي للمكافآت", "Daily reward cap"), T("أقصى رصيد يُكسب في اليوم (0 = بلا حد)", "Max credit earned per day (0 = no cap)"), true, if (FocusStore.cap > 0.0) FocusStore.fmt(FocusStore.cap) else "") { v ->
                FocusStore.cap = v
                FocusStore.save(true)
                render()
            }
        }
        card.addView(capV)
        if (FocusStore.cap > 0.0) {
            val ratio = (FocusStore.earnedNow() / FocusStore.cap).coerceIn(0.0, 1.0).toFloat()
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.background = Ui.shape(PalGen.alpha(pal.fg, 30), 0, dp(3).toFloat())
            val fill = View(this)
            fill.background = Ui.shape(if (ratio >= 1f) pal.warn else pal.accent, 0, dp(3).toFloat())
            bar.addView(fill, LinearLayout.LayoutParams(0, dp(6), ratio.coerceAtLeast(0.001f)))
            bar.addView(View(this), LinearLayout.LayoutParams(0, dp(6), (1f - ratio).coerceAtLeast(0.001f)))
            card.addView(bar, Ui.lp(Ui.MP, dp(6)))
        }
        box.addView(card, Ui.lp(Ui.MP, Ui.WC, dp(12)))

        val taskLink = Ui.btn(this, T("ارجع إلى المهام لإضافة مكافأة لمهمة  ↗", "Return to Tasks to add a task reward  ↗"), Color.TRANSPARENT, pal.accent)
        taskLink.textSize = 13f
        taskLink.setOnClickListener { finish() }
        box.addView(taskLink, Ui.lp(Ui.MP, Ui.WC, dp(2)))

        // حالة المراقبة والحظر
        if (!FocusService.enabled(this)) {
            val w = LinearLayout(this)
            w.orientation = LinearLayout.VERTICAL
            w.setPadding(dp(14), dp(12), dp(14), dp(12))
            w.background = Ui.shape(PalGen.alpha(pal.warn, 38), 0, dp(16).toFloat())
            w.addView(Ui.tv(this, T("المراقبة والحظر غير مفعّلين", "Monitoring & blocking are off"), 14f, pal.fg, true))
            w.addView(
                Ui.tv(
                    this,
                    T(
                        "فعّل خدمة «أهدافي Focus» من إعدادات إمكانية الوصول. على أندرويد 13+ وللتطبيق المثبّت خارج المتجر: افتح «معلومات التطبيق» ← ⋮ ← «السماح بالإعدادات المقيّدة» أولًا. الخدمة لا تقرأ محتوى الشاشة.",
                        "Enable the \"Ahdafi Focus\" service in Accessibility settings. On Android 13+ with a sideloaded app: open App info → ⋮ → \"Allow restricted settings\" first. The service never reads screen content."
                    ),
                    12f, pal.muted
                ), Ui.lp(Ui.MP, Ui.WC, dp(4))
            )
            val b1 = Ui.btn(this, T("فتح إعدادات إمكانية الوصول", "Open Accessibility settings"), pal.warn, onAccent())
            b1.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            w.addView(b1, Ui.lp(Ui.MP, Ui.WC, dp(10)))
            val b2 = Ui.btn(this, T("معلومات التطبيق", "App info"), Color.TRANSPARENT, pal.muted)
            b2.setOnClickListener {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:" + packageName)
                startActivity(i)
            }
            w.addView(b2, Ui.lp(Ui.MP, Ui.WC, dp(2)))
            box.addView(w, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        } else {
            val ago = if (FocusStore.hb == 0L) -1L else (SystemClock.elapsedRealtime() - FocusStore.hb) / 1000
            if (ago in 0L..8L) {
                box.addView(Ui.tv(this, T("● المراقبة تعمل · آخر قراءة قبل ", "● Monitoring on · last read ") + ago + T(" ث", " s ago"), 12f, pal.accent), Ui.lp(Ui.MP, Ui.WC, dp(8)))
            } else {
                val w = LinearLayout(this)
                w.orientation = LinearLayout.VERTICAL
                w.setPadding(dp(14), dp(12), dp(14), dp(12))
                w.background = Ui.shape(PalGen.alpha(pal.warn, 38), 0, dp(16).toFloat())
                w.addView(Ui.tv(this, T("الخدمة مفعّلة لكنها متوقفة عن القراءة", "Service is on but not reading"), 14f, pal.fg, true))
                w.addView(
                    Ui.tv(
                        this,
                        T(
                            "غالبًا أوقفها نظام توفير البطارية. استثنِ التطبيق من توفير البطارية، وفعّل «التشغيل التلقائي»، ثم أطفئ الخدمة وشغّلها من إعدادات إمكانية الوصول.",
                            "Battery saver probably stopped it. Exempt the app from battery optimization, enable autostart, then toggle the service off and on in Accessibility settings."
                        ),
                        12f, pal.muted
                    ), Ui.lp(Ui.MP, Ui.WC, dp(4))
                )
                val b1 = Ui.btn(this, T("إعادة تفعيل الخدمة", "Re-enable the service"), pal.warn, onAccent())
                b1.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                w.addView(b1, Ui.lp(Ui.MP, Ui.WC, dp(10)))
                keepAlive(w)
                box.addView(w, Ui.lp(Ui.MP, Ui.WC, dp(10)))
            }
        }

        // العادات: أسهل طريقة لبدء كسب الرصيد
        section(T("العادات", "Habits"), T("علّم العادة كمكتملة لتحصل على مكافأتها. ويمكنك أيضًا ربط مكافأة بأي مهمة من شاشة إضافة المهمة.", "Tap Done to claim a habit reward. You can also attach a reward to any task from the task editor."), "habits")
        if (FocusStore.habits.isEmpty()) emptyHint(T("لم تضف عادات بعد. ابدأ بعادة بسيطة مثل القراءة أو التمرين.", "No habits yet. Start with something simple, like reading or exercise."))
        for (h in FocusStore.habits) habitRow(h)
        addRow(T("+ إضافة عادة", "+ Add habit")) { habitDialog(null) }
        sep()

        // التطبيقات المنتجة
        section(T("تطبيقات تكسب رصيدًا", "Apps that earn credit"), T("يكسب التطبيق رصيدًا أثناء استخدامه في الواجهة، حسب المعدل الذي تحدده.", "Earn credit while these apps are in the foreground, at the rate you choose."), "earn")
        if (FocusStore.earn.isEmpty()) emptyHint(T("اختياري: أضف تطبيقًا تستخدمه للتعلم أو القراءة أو العمل.", "Optional: add an app you use for learning, reading or work."))
        for (a in FocusStore.earn) appRow(a, true)
        addRow(T("+ إضافة تطبيق منتج", "+ Add earning app")) { pickApp(true) }
        sep()

        // التطبيقات المستهلكة
        section(T("تطبيقات تستهلك الرصيد", "Apps that spend credit"), T("تُخصم تكلفة كل دقيقة. عند نفاد الرصيد، يحاول Focus حظر التطبيق المحدد.", "Each minute deducts credit. When the balance runs out, Focus attempts to block the selected app."), "spend")
        if (FocusStore.spend.isEmpty()) emptyHint(T("لم تحدد تطبيقات للحد منها؛ لن يحظر Focus أي تطبيق حتى تضيفه هنا.", "No limited apps selected. Focus will not block any app until you add one here."))
        for (a in FocusStore.spend) appRow(a, false)
        addRow(T("+ إضافة تطبيق محدود", "+ Add limited app")) { pickApp(false) }
        sep()

        // سجل الرصيد
        section(T("سجل الرصيد", "Balance history"), T("كل المكافآت والخصومات الأخيرة", "Recent rewards and deductions"), "history")
        if (FocusStore.log.isEmpty()) {
            box.addView(Ui.tv(this, T("لا حركات بعد", "No activity yet"), 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(8)))
        }
        var lastDay = -1
        for (l in FocusStore.log.take(logShown)) {
            val dk = dayKeyOf(l.ts)
            if (dk != lastDay) {
                lastDay = dk
                val hd = Ui.tv(this, dayLabel(l.ts), 12f, pal.muted, true)
                hd.setPadding(0, dp(12), 0, dp(2))
                box.addView(hd, Ui.lp(Ui.MP, Ui.WC))
            }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(7), 0, dp(7))
            row.addView(Ui.tv(this, l.label, 14f, pal.fg), LinearLayout.LayoutParams(0, Ui.WC, 1f))
            val tm = Ui.tv(this, timeStr(l.ts), 11f, pal.muted)
            tm.setPadding(dp(8), 0, dp(10), 0)
            row.addView(tm)
            val pos = l.delta >= 0
            row.addView(Ui.tv(this, (if (pos) "+" else "−") + FocusStore.fmt(Math.abs(l.delta)), 14f, if (pos) pal.accent else pal.warn, true))
            box.addView(row, Ui.lp(Ui.MP, Ui.WC))
        }
        if (FocusStore.log.size > logShown) addRow(T("عرض المزيد", "Show more")) {
            logShown += 30
            render()
        }
    }

    private fun dayKeyOf(ts: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    private fun dayLabel(ts: Long): String {
        val k = dayKeyOf(ts)
        if (k == dayKeyOf(System.currentTimeMillis())) return T("اليوم", "Today")
        if (k == dayKeyOf(System.currentTimeMillis() - 86400000L)) return T("أمس", "Yesterday")
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.DAY_OF_MONTH).toString() + "/" + (c.get(Calendar.MONTH) + 1)
    }

    private fun timeStr(ts: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    private fun appRow(a: FApp, earn: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(9), 0, dp(9))
        val ic = ImageView(this)
        ic.setImageDrawable(icon(a.pkg))
        row.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
        val nmCol = LinearLayout(this)
        nmCol.orientation = LinearLayout.VERTICAL
        nmCol.setPadding(dp(12), 0, dp(12), 0)
        nmCol.addView(Ui.tv(this, a.name, 15f, pal.fg))
        nmCol.addView(Ui.tv(this, T("اليوم: ", "Today: ") + fmtDur(a.today), 11f, pal.muted))
        row.addView(nmCol, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        val txt = (if (earn) "+" else "−") + FocusStore.fmt(a.rate) + T(" / دقيقة", " /min")
        row.addView(Ui.tv(this, txt, 13f, if (earn) pal.accent else pal.warn, true))
        val editMark = Ui.tv(this, "  ›", 18f, pal.muted)
        row.addView(editMark)
        row.contentDescription = T("اضغط لتعديل معدل التطبيق: ", "Tap to edit app rate: ") + a.name
        row.setOnClickListener { rateDialog(a, earn, a.pkg, a.name) }
        box.addView(row, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun rewardText(h: FHabit): String = when (h.kind) {
        1 -> "+" + FocusStore.fmt(h.value) + T(" / دقيقة", " /min")
        2 -> "+" + FocusStore.fmt(h.value) + T(" عند الإنجاز", " on done")
        else -> T("مكافأة يدوية", "Manual reward")
    }

    private fun habitRow(h: FHabit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(9), 0, dp(9))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.tv(this, h.title, 15f, pal.fg))
        col.addView(Ui.tv(this, rewardText(h), 12f, pal.muted))
        row.addView(col, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        val done = Ui.chip(this, T("إتمام", "Done"), pal, true)
        done.setOnClickListener { completeHabit(h) }
        row.addView(done)
        row.addView(Ui.tv(this, "  ✎", 14f, pal.muted))
        row.contentDescription = T("اضغط لتعديل العادة: ", "Tap to edit habit: ") + h.title
        row.setOnClickListener { habitDialog(h) }
        box.addView(row, Ui.lp(Ui.MP, Ui.WC))
    }

    private fun reward(v: Double, h: FHabit) {
        val a = FocusStore.add(v, h.title, "h:" + h.id, false)
        if (a > 0) {
            h.last = System.currentTimeMillis()
            FocusStore.save(true)
            Toast.makeText(this, "+" + FocusStore.fmt(a), Toast.LENGTH_SHORT).show()
        } else if (FocusStore.capReached()) {
            Toast.makeText(this, T("وصلت للحد اليومي للمكافآت", "Daily reward cap reached"), Toast.LENGTH_SHORT).show()
        }
        render()
    }

    private fun doComplete(h: FHabit) {
        when (h.kind) {
            2 -> reward(h.value, h)
            1 -> askNumber(h.title, T("كم دقيقة؟", "How many minutes?")) { m -> reward(m * h.value, h) }
            else -> askNumber(h.title, T("كم نقطة تكسب؟", "Points to earn?")) { v -> reward(v, h) }
        }
    }

    // منع تكرار المكافأة دون قصد: إن كوفئت العادة قبل أقل من 10 دقائق يُطلب تأكيد
    private fun completeHabit(h: FHabit) {
        val ago = System.currentTimeMillis() - h.last
        if (h.last > 0 && ago < 10 * 60 * 1000L) {
            val d = newDialog()
            val col = column()
            col.addView(Ui.tv(this, h.title, 17f, pal.fg, true))
            val mins = (ago / 60000L).toInt()
            val msg = if (mins == 0) T("كوفئت هذه العادة للتو. هل تريد مكافأتها مرة أخرى؟", "This habit was just rewarded. Reward it again?")
            else T("كوفئت هذه العادة قبل " + mins + " دقيقة. هل تريد مكافأتها مرة أخرى؟", "This habit was rewarded " + mins + " min ago. Reward it again?")
            col.addView(Ui.tv(this, msg, 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(6)))
            col.addView(buttons(d, T("مكافأة مرة أخرى", "Reward again"), {
                d.dismiss()
                doComplete(h)
            }, null), Ui.lp(Ui.MP, Ui.WC, dp(14)))
            showDialog(d, col)
        } else doComplete(h)
    }

    // ---------- نوافذ ----------

    private fun newDialog(): Dialog {
        val d = Dialog(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
        return d
    }

    private fun showDialog(d: Dialog, col: View) {
        d.setContentView(col)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(Ui.shape(pal.glass or (0xFF shl 24), pal.line, dp(22).toFloat(), 1))
            w.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun column(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = Lang.dir
        col.setPadding(dp(18), dp(16), dp(18), dp(14))
        return col
    }

    private fun edit(hint: String, text: String, numeric: Boolean): EditText {
        val e = EditText(this)
        e.setSingleLine(true)
        e.hint = hint
        e.setText(text)
        e.setTextColor(pal.fg)
        e.setHintTextColor(pal.muted)
        e.textSize = 15f
        e.background = Ui.shape(PalGen.alpha(pal.fg, 18), 0, dp(12).toFloat())
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        return e
    }

    // صف أزرار متساوية: حفظ / (حذف بتأكيد) / إلغاء
    private fun buttons(d: Dialog, saveText: String, onSave: () -> Unit, onDelete: (() -> Unit)?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun style(b: TextView) {
            b.textSize = 15f
            b.maxLines = 1
            b.setPadding(dp(6), dp(12), dp(6), dp(12))
        }
        val save = Ui.btn(this, saveText, pal.accent, onAccent())
        style(save)
        save.setOnClickListener { onSave() }
        val lp1 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
        lp1.marginEnd = dp(6)
        row.addView(save, lp1)
        if (onDelete != null) {
            val del = Ui.btn(this, T("حذف", "Delete"), Color.TRANSPARENT, pal.warn)
            style(del)
            var armed = false
            del.setOnClickListener {
                if (!armed) {
                    armed = true
                    del.text = T("تأكيد الحذف", "Confirm delete")
                } else onDelete()
            }
            val lp2 = LinearLayout.LayoutParams(0, Ui.WC, 1f)
            lp2.marginEnd = dp(6)
            row.addView(del, lp2)
        }
        val cancel = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        style(cancel)
        cancel.setOnClickListener { d.dismiss() }
        row.addView(cancel, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        return row
    }

    private fun askNumber(title: String, label: String, allowZero: Boolean = false, initial: String = "", cb: (Double) -> Unit) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, title, 17f, pal.fg, true))
        col.addView(Ui.tv(this, label, 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(4)))
        val e = edit("", initial, true)
        col.addView(e, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        col.addView(buttons(d, T("تم", "OK"), {
            val v = num(e.text.toString())
            if (v == null || v < 0.0 || (!allowZero && v <= 0.0)) {
                Toast.makeText(this, if (allowZero) T("أدخل رقمًا صحيحًا", "Enter a valid number") else T("أدخل رقمًا أكبر من صفر", "Enter a number above zero"), Toast.LENGTH_SHORT).show()
            } else {
                d.dismiss()
                cb(v)
            }
        }, null), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    private fun rateDialog(existing: FApp?, earn: Boolean, pkg: String, name: String) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, name, 17f, pal.fg, true))
        val q = if (earn) T("كم تكسب لكل دقيقة استخدام؟", "Credit earned per minute of use") else T("كم تكلّف الدقيقة من الرصيد؟", "Credit cost per minute")
        col.addView(Ui.tv(this, q, 13f, pal.muted), Ui.lp(Ui.MP, Ui.WC, dp(4)))
        val e = edit("1", FocusStore.fmt(existing?.rate ?: 1.0), true)
        col.addView(e, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val del: (() -> Unit)? = if (existing == null) null else {
            {
                if (earn) FocusStore.earn.remove(existing) else FocusStore.spend.remove(existing)
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }
        col.addView(buttons(d, T("حفظ", "Save"), {
            val v = num(e.text.toString())
            if (v == null || v <= 0.0) {
                Toast.makeText(this, T("أدخل رقمًا أكبر من صفر", "Enter a number above zero"), Toast.LENGTH_SHORT).show()
            } else {
                if (existing != null) existing.rate = v
                else if (earn) FocusStore.earn.add(FApp(pkg, name, v))
                else FocusStore.spend.add(FApp(pkg, name, v))
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }, del), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    private fun habitDialog(h: FHabit?) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, if (h == null) T("عادة جديدة", "New habit") else T("تعديل العادة", "Edit habit"), 17f, pal.fg, true))
        val title = edit(T("اسم العادة", "Habit name"), h?.title ?: "", false)
        col.addView(title, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        var kind = h?.kind ?: 2
        val names = arrayOf(T("يدوي", "Manual"), T("لكل دقيقة", "Per minute"), T("ثابت", "Fixed"))
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        col.addView(chips, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val hint = Ui.tv(this, "", 13f, pal.muted)
        col.addView(hint, Ui.lp(Ui.MP, Ui.WC, dp(10)))
        val value = edit("1", FocusStore.fmt(h?.value ?: 1.0), true)
        col.addView(value, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        fun paint() {
            chips.removeAllViews()
            for (i in 0..2) {
                val c = Ui.chip(this, names[i], pal, kind == i)
                c.setOnClickListener {
                    kind = i
                    paint()
                }
                val lp = LinearLayout.LayoutParams(0, Ui.WC, 1f)
                lp.marginEnd = dp(6)
                chips.addView(c, lp)
            }
            value.visibility = if (kind == 0) View.GONE else View.VISIBLE
            hint.text = when (kind) {
                0 -> T("تحدد المكافأة بنفسك عند كل إتمام", "You enter the reward each time")
                1 -> T("نقاط لكل دقيقة", "Credit per minute")
                else -> T("نقاط ثابتة عند الإنجاز", "Fixed credit on completion")
            }
        }
        paint()
        val del: (() -> Unit)? = if (h == null) null else {
            {
                FocusStore.habits.remove(h)
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }
        col.addView(buttons(d, T("حفظ", "Save"), {
            val t = title.text.toString().trim()
            val v = if (kind == 0) 0.0 else (num(value.text.toString()) ?: 0.0)
            if (t.isEmpty() || (kind != 0 && v <= 0.0)) {
                Toast.makeText(this, T("أكمل الاسم والمكافأة", "Fill in the name and reward"), Toast.LENGTH_SHORT).show()
            } else {
                if (h != null) {
                    h.title = t
                    h.kind = kind
                    h.value = v
                } else FocusStore.habits.add(FHabit(Store.uid(), t, kind, v))
                FocusStore.save(true)
                d.dismiss()
                render()
            }
        }, del), Ui.lp(Ui.MP, Ui.WC, dp(14)))
        showDialog(d, col)
    }

    // اختيار تطبيق من التطبيقات القابلة للتشغيل (تُحمَّل في خيط خلفي)
    private fun pickApp(earn: Boolean) {
        Thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_LAUNCHER)
            val taken = HashSet<String>()
            for (a in FocusStore.earn) taken.add(a.pkg)
            for (a in FocusStore.spend) taken.add(a.pkg)
            val seen = HashSet<String>()
            val list = ArrayList<PApp>()
            try {
                for (ri in pm.queryIntentActivities(i, 0)) {
                    val p = ri.activityInfo.packageName
                    if (p == packageName || p in taken || !seen.add(p)) continue
                    list.add(PApp(p, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
                }
            } catch (e: Exception) {
            }
            list.sortBy { it.name.lowercase() }
            runOnUiThread { if (!isFinishing) showPicker(list, earn) }
        }.start()
    }

    private fun showPicker(list: List<PApp>, earn: Boolean) {
        val d = newDialog()
        val col = column()
        col.addView(Ui.tv(this, T("اختر تطبيقًا", "Choose an app"), 17f, pal.fg, true))
        val q = edit(T("بحث", "Search"), "", false)
        col.addView(q, Ui.lp(Ui.MP, Ui.WC, dp(8)))
        val lst = LinearLayout(this)
        lst.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(lst)
        col.addView(sv, Ui.lp(Ui.MP, dp(380), dp(8)))
        fun fill(f: String) {
            lst.removeAllViews()
            if (list.isEmpty()) lst.addView(Ui.tv(this, T("لا توجد تطبيقات متاحة", "No apps available"), 13f, pal.muted))
            for (a in list) {
                if (f.isNotEmpty() && !a.name.lowercase().contains(f)) continue
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(8), 0, dp(8))
                val ic = ImageView(this)
                ic.setImageDrawable(a.icon)
                row.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
                val nm = Ui.tv(this, a.name, 15f, pal.fg)
                nm.setPadding(dp(12), 0, 0, 0)
                row.addView(nm, LinearLayout.LayoutParams(0, Ui.WC, 1f))
                row.setOnClickListener {
                    d.dismiss()
                    rateDialog(null, earn, a.pkg, a.name)
                }
                lst.addView(row, Ui.lp(Ui.MP, Ui.WC))
            }
        }
        fill("")
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                fill((s?.toString() ?: "").trim().lowercase())
            }
        })
        val close = Ui.btn(this, T("إلغاء", "Cancel"), Color.TRANSPARENT, pal.muted)
        close.setOnClickListener { d.dismiss() }
        col.addView(close, Ui.lp(Ui.MP, Ui.WC, dp(6)))
        showDialog(d, col)
    }
}
