package app.goals

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

// مراقبة التطبيق المفتوح فعليًا في الواجهة لاحتساب الرصيد، وحظر التطبيقات المستهلكة عند نفاده.
// الموثوقية: التطبيق الحالي يُقرأ من النافذة النشطة كل ثانية (لا نعتمد على الأحداث وحدها)،
// وكل خطوة محمية من الاستثناءات حتى لا تتوقف الخدمة أو يعطّلها النظام بسبب تعطّل.
class FocusService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var cur = ""
    private var last = 0L
    private var lastBlock = 0L
    private var lastSheet = 0L
    private var lastTick = 0L
    private var n = 0
    private var registered = false
    private val ignore = HashSet<String>()

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Throwable) {
            }
            lastTick = SystemClock.elapsedRealtime()
            h.postDelayed(this, 1000)
        }
    }

    private val screen = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                // عند تشغيل الشاشة نبدأ العدّ من الآن حتى لا يُحتسب وقت الإطفاء
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> last = SystemClock.elapsedRealtime()
                Intent.ACTION_SCREEN_OFF -> {
                    cur = ""
                    FocusStore.save(true)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        FocusStore.init(this)
        refreshIgnore()
        last = SystemClock.elapsedRealtime()
        if (!registered) {
            try {
                val f = IntentFilter()
                f.addAction(Intent.ACTION_SCREEN_ON)
                f.addAction(Intent.ACTION_SCREEN_OFF)
                f.addAction(Intent.ACTION_USER_PRESENT)
                registerReceiver(screen, f)
                registered = true
            } catch (e: Exception) {
            }
        }
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun refreshIgnore() {
        ignore.clear()
        ignore.add("com.android.systemui")
        ignore.add("android")
        try {
            val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (i in im.enabledInputMethodList) ignore.add(i.packageName)
        } catch (e: Exception) {
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            // حارس: إن توقف المؤقّت لأي سبب نعيد تشغيله
            if (SystemClock.elapsedRealtime() - lastTick > 5000) {
                h.removeCallbacks(tick)
                h.post(tick)
            }
            if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val p = e.packageName?.toString() ?: return
            if (p in ignore) return
            if (p != cur) {
                cur = p
                if (FocusStore.spendApp(cur) != null && FocusStore.earnApp(cur) == null && FocusStore.bal <= 0.0) block()
            }
        } catch (x: Throwable) {
        }
    }

    // قراءة التطبيق الأمامي من النافذة النشطة (مصدر مستقل عن الأحداث)
    private fun readForeground() {
        var node: AccessibilityNodeInfo? = null
        try {
            node = rootInActiveWindow
            val p = node?.packageName?.toString()
            if (p != null && p !in ignore) cur = p
        } catch (e: Exception) {
        } finally {
            try {
                node?.recycle()
            } catch (e: Exception) {
            }
        }
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val dt = now - last
        last = now
        FocusStore.hb = now
        if (++n % 60 == 0) refreshIgnore()
        FocusStore.save()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        // لا احتساب والشاشة مطفأة أو مقفلة (منع احتساب الخلفية)
        if (!pm.isInteractive || km.isKeyguardLocked) {
            cur = ""
            return
        }
        readForeground()
        FocusStore.curPkg = cur
        if (cur.isEmpty()) return
        // سقف للفارق الزمني حتى لا يُحتسب الوقت مرتين أو دفعة واحدة بعد تعليق النظام
        val sec = dt.coerceIn(0L, 6000L) / 1000.0
        val e = FocusStore.earnApp(cur)
        if (e != null) {
            FocusStore.use(e, sec)
            FocusStore.add(e.rate * sec / 60.0, e.name, "e:" + cur, true)
            return
        }
        val s = FocusStore.spendApp(cur) ?: return
        if (FocusStore.bal <= 0.0) {
            block()
            return
        }
        FocusStore.use(s, sec)
        FocusStore.add(-s.rate * sec / 60.0, s.name, "s:" + cur, true)
        if (FocusStore.bal <= 0.0) block()
    }

    // الحظر: إخراج المستخدم للشاشة الرئيسية، ويتكرر عند كل قراءة إن عاد للتطبيق نفسه
    private fun block() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 1200) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            Toast.makeText(this, T("انتهى رصيد Focus", "Focus credit is over"), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
        if (now - lastSheet > 8000) {
            lastSheet = now
            try {
                val i = Intent(this, FocusBlockActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        h.removeCallbacks(tick)
        if (registered) {
            try {
                unregisterReceiver(screen)
            } catch (e: Exception) {
            }
            registered = false
        }
        FocusStore.hb = 0L
        FocusStore.save(true)
        super.onDestroy()
    }

    companion object {
        fun enabled(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(c, FocusService::class.java)
            for (x in s.split(':')) {
                val cn = ComponentName.unflattenFromString(x) ?: continue
                if (cn == me) return true
            }
            return false
        }
    }
}
