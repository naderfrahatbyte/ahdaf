package app.goals

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    fun shape(fill: Int, stroke: Int, r: Float, sw: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = r
        if (sw > 0) g.setStroke(sw, stroke)
        return g
    }

    fun btn(c: Context, t: String, bg: Int, fg: Int): TextView {
        val v = tv(c, t, 16f, fg, true)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
        v.background = shape(bg, 0, dp(c, 12).toFloat())
        return v
    }

    fun chip(c: Context, t: String, pal: Pal, on: Boolean): TextView {
        val v = tv(c, t, 14f, if (on) pal.accent else pal.muted, on)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        v.background = shape(if (on) PalGen.alpha(pal.accent, 45) else Color.TRANSPARENT, pal.line, dp(c, 18).toFloat(), dp(c, 1).coerceAtLeast(1))
        return v
    }

    fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h)
        l.topMargin = top
        return l
    }

    val MP = ViewGroup.LayoutParams.MATCH_PARENT
    val WC = ViewGroup.LayoutParams.WRAP_CONTENT
}

// نفس خلفية واجهة التطبيق (الويب): خلفية داكنة مع توهّج ذهبي أعلى اليمين وبنفسجي أسفل اليسار
class AppBgDrawable : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun glow(c: Canvas, w: Float, h: Float, cx: Float, cy: Float, rx: Float, ry: Float, r: Int, g: Int, b: Int, a: Int) {
        val sh = RadialGradient(0f, 0f, 1f, intArrayOf(Color.argb(a, r, g, b), Color.argb(0, r, g, b)), floatArrayOf(0f, 0.62f), Shader.TileMode.CLAMP)
        val m = Matrix()
        m.setScale(rx * w, ry * h)
        m.postTranslate(cx * w, cy * h)
        sh.setLocalMatrix(m)
        paint.shader = sh
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.drawColor(Color.parseColor("#0a0712"))
        glow(canvas, w, h, 0.90f, -0.08f, 0.80f, 0.45f, 255, 196, 110, 56)
        glow(canvas, w, h, -0.10f, 1.05f, 0.70f, 0.45f, 125, 85, 175, 71)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object AppChrome {
    // أشرطة النظام بنفس لون خلفية التطبيق حتى لا يظهر أي فاصل بين الشاشات
    fun bars(a: Activity) {
        val bg = Color.parseColor("#0a0712")
        a.window.statusBarColor = bg
        a.window.navigationBarColor = bg
        a.window.decorView.setBackgroundColor(bg)
        if (Build.VERSION.SDK_INT >= 29) {
            a.window.isStatusBarContrastEnforced = false
            a.window.isNavigationBarContrastEnforced = false
        }
        a.window.decorView.systemUiVisibility = 0
    }

    // زر أيقونة بنفس شكل أزرار الهيدر في الويب (40dp، حواف 12، خلفية خفيفة عند الضغط)
    fun iconBtn(c: Context, glyph: String, color: Int, pressedFill: Int, sizeSp: Float = 22f): TextView {
        val v = Ui.tv(c, glyph, sizeSp, color, true)
        v.gravity = Gravity.CENTER
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), Ui.shape(pressedFill, 0, Ui.dp(c, 12).toFloat()))
        sl.addState(intArrayOf(), Ui.shape(Color.TRANSPARENT, 0, Ui.dp(c, 12).toFloat()))
        v.background = sl
        return v
    }
}

object Glass {
    fun apply(a: Activity, pal: Pal, frac: Float = 0.92f) {
        val d = a.resources.displayMetrics.density
        val bg = GradientDrawable()
        bg.setColor(pal.glass)
        bg.cornerRadius = 26 * d
        bg.setStroke(d.toInt().coerceAtLeast(1), pal.line)
        a.window.setBackgroundDrawable(bg)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                a.window.setBackgroundBlurRadius((45 * d).toInt())
            } catch (e: Exception) {
            }
        }
        a.window.setLayout((a.resources.displayMetrics.widthPixels * frac).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}

object Backup {
    const val EXPORT = 7101
    const val IMPORT = 7102

    fun export(a: Activity) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "ahdaf-backup-" + dateStr(todayDay()) + ".json")
        a.startActivityForResult(i, EXPORT)
    }

    fun importFile(a: Activity) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        a.startActivityForResult(i, IMPORT)
    }

    fun result(a: Activity, req: Int, res: Int, data: Intent?) {
        if (res != Activity.RESULT_OK || data == null) return
        val u = data.data ?: return
        try {
            if (req == EXPORT) {
                a.contentResolver.openOutputStream(u)?.use { val full = JSONObject(Store.data(a).toString())
                    full.put("focus", FocusStore.snapshot(a))
                    it.write(full.toString().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(a, T("تم حفظ النسخة الاحتياطية", "Backup saved"), Toast.LENGTH_SHORT).show()
            } else if (req == IMPORT) {
                val txt = a.contentResolver.openInputStream(u)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: return
                val o = JSONObject(txt)
                if (!o.has("goals") && !o.has("loose") && !o.has("lists")) {
                    Toast.makeText(a, T("الملف غير صالح", "Invalid file"), Toast.LENGTH_SHORT).show()
                    return
                }
                val fo = o.optJSONObject("focus")
                val ga = o.optJSONArray("goals")
                var tasks = o.optJSONArray("loose")?.length() ?: 0
                for (i in 0 until (ga?.length() ?: 0)) tasks += ga?.optJSONObject(i)?.optJSONArray("tasks")?.length() ?: 0
                val msg = T(
                    "سيتم استبدال بياناتك الحالية بمحتوى الملف: " + (ga?.length() ?: 0) + " أهداف، " + tasks + " مهام، " + (o.optJSONArray("lists")?.length() ?: 0) + " قوائم.\n",
                    "Your current data will be replaced by the file: " + (ga?.length() ?: 0) + " goals, " + tasks + " tasks, " + (o.optJSONArray("lists")?.length() ?: 0) + " lists.\n"
                ) + (if (fo != null) T("بيانات Focus ستُستبدل أيضًا بما في الملف.", "Focus data will also be replaced by the file's.")
                else T("بيانات Focus الحالية ستبقى كما هي.", "Your current Focus data stays as it is."))
                AlertDialog.Builder(a)
                    .setTitle(T("استيراد نسخة احتياطية", "Import backup"))
                    .setMessage(msg)
                    .setPositiveButton(T("استبدال", "Replace")) { _, _ ->
                        if (fo != null) FocusStore.restore(a, fo)
                        o.remove("focus")
                        Store.save(a, o)
                        GoalsWidget.refresh(a)
                        (a as? MainActivity)?.postWebEvent("data_changed")
                        Toast.makeText(a, T("تم الاستيراد", "Imported"), Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton(T("إلغاء", "Cancel"), null)
                    .show()
            }
        } catch (e: Exception) {
            Toast.makeText(a, T("تعذّر تنفيذ العملية", "Something went wrong"), Toast.LENGTH_SHORT).show()
        }
    }
}
