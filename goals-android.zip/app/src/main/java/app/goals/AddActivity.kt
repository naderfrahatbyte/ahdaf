package app.goals

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class AddActivity : Activity() {
    private var kind = 0
    private var date = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val d = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()
        val m = Model(this)
        date = Store.sel(this)
        val goals = m.goals.filter { !it.long }
        val lists = m.lists
        val white = Color.WHITE
        val soft = Color.argb(34, 255, 255, 255)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(18), dp(16), dp(18), dp(16))

        val head = TextView(this)
        head.text = "إضافة مهمة"
        head.textSize = 19f
        head.setTextColor(white)
        head.typeface = Typeface.DEFAULT_BOLD
        root.addView(head)

        val title = EditText(this)
        title.hint = "اكتب المهمة"
        title.setTextColor(white)
        title.setHintTextColor(Color.argb(130, 255, 255, 255))
        title.setSingleLine(true)
        root.addView(title, LinearLayout.LayoutParams(mp, wc))

        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        val lpRow = LinearLayout.LayoutParams(mp, wc)
        lpRow.topMargin = dp(10)
        root.addView(chipRow, lpRow)

        val spGoal = Spinner(this)
        val goalNames = ArrayList<String>()
        for (g in goals) goalNames.add(g.title)
        if (goalNames.isEmpty()) goalNames.add("لا توجد أهداف (أضف هدفًا من التطبيق)")
        val ga = ArrayAdapter(this, android.R.layout.simple_spinner_item, goalNames)
        ga.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spGoal.adapter = ga
        root.addView(spGoal, LinearLayout.LayoutParams(mp, wc))

        val spList = Spinner(this)
        val listNames = ArrayList<String>()
        for (l in lists) listNames.add(l.title)
        listNames.add("+ قائمة جديدة")
        val la = ArrayAdapter(this, android.R.layout.simple_spinner_item, listNames)
        la.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spList.adapter = la
        root.addView(spList, LinearLayout.LayoutParams(mp, wc))

        val newList = EditText(this)
        newList.hint = "اسم القائمة الجديدة"
        newList.setTextColor(white)
        newList.setHintTextColor(Color.argb(130, 255, 255, 255))
        newList.setSingleLine(true)
        root.addView(newList, LinearLayout.LayoutParams(mp, wc))

        val dateBtn = Button(this)
        fun dateLabel(): String {
            val c = civil(date)
            return "اليوم: " + c[2] + " " + MONTHS[c[1] - 1] + " " + c[0]
        }
        dateBtn.text = dateLabel()
        dateBtn.setOnClickListener {
            val c = civil(date)
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, y, mo, dd ->
                date = ymd(y, mo + 1, dd)
                dateBtn.text = dateLabel()
            }, c[0], c[1] - 1, c[2]).show()
        }
        root.addView(dateBtn, LinearLayout.LayoutParams(mp, wc))

        val chips = ArrayList<TextView>()
        fun refreshUi() {
            for (i in chips.indices) chips[i].setBackgroundColor(if (i == kind) ACCENT else soft)
            spGoal.visibility = if (kind == 1) View.VISIBLE else View.GONE
            spList.visibility = if (kind == 2) View.VISIBLE else View.GONE
            newList.visibility = if (kind == 2 && spList.selectedItemPosition == lists.size) View.VISIBLE else View.GONE
            dateBtn.visibility = if (kind == 2) View.GONE else View.VISIBLE
        }
        val names = arrayOf("عادية", "ضمن هدف", "في قائمة")
        for (i in names.indices) {
            val chip = TextView(this)
            chip.text = names[i]
            chip.textSize = 15f
            chip.setTextColor(white)
            chip.gravity = android.view.Gravity.CENTER
            chip.setPadding(dp(6), dp(10), dp(6), dp(10))
            chip.setOnClickListener {
                kind = i
                refreshUi()
            }
            chips.add(chip)
            val lp = LinearLayout.LayoutParams(0, wc, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            chipRow.addView(chip, lp)
        }
        spList.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                refreshUi()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        refreshUi()

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val save = Button(this)
        save.text = "إضافة"
        val cancel = Button(this)
        cancel.text = "إلغاء"
        cancel.setOnClickListener { finish() }
        save.setOnClickListener {
            val t = title.text.toString().trim()
            if (t.isEmpty()) {
                Toast.makeText(this, "اكتب المهمة أولًا", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            when (kind) {
                0 -> Store.addLoose(this, t, dateStr(date))
                1 -> {
                    if (goals.isEmpty()) {
                        Toast.makeText(this, "لا توجد أهداف، أضف هدفًا من التطبيق", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    val g = goals[spGoal.selectedItemPosition]
                    val dd = minOf(maxOf(date, g.s), g.e)
                    if (dd != date) Toast.makeText(this, "تم ضبط اليوم داخل مدى الهدف", Toast.LENGTH_SHORT).show()
                    Store.addGoalTask(this, g.id, t, dateStr(dd))
                }
                else -> {
                    val pos = spList.selectedItemPosition
                    val lid: String
                    if (pos >= lists.size) {
                        val nm = newList.text.toString().trim()
                        if (nm.isEmpty()) {
                            Toast.makeText(this, "اكتب اسم القائمة", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        lid = Store.addList(this, nm)
                    } else lid = lists[pos].id
                    Store.addListItem(this, lid, t)
                    Store.setMode(this, 2)
                }
            }
            if (kind != 2) Store.setMode(this, 0)
            GoalsWidget.refresh(this)
            finish()
        }
        btns.addView(save, LinearLayout.LayoutParams(0, wc, 1f))
        btns.addView(cancel, LinearLayout.LayoutParams(0, wc, 1f))
        val lpB = LinearLayout.LayoutParams(mp, wc)
        lpB.topMargin = dp(10)
        root.addView(btns, lpB)

        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#0d1a45"))
        bg.cornerRadius = 22 * d
        window.setBackgroundDrawable(bg)
        setContentView(root)
        window.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
