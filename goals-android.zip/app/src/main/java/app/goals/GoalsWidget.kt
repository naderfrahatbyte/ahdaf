package app.goals

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews

private val ROW = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4, R.id.row5, R.id.row6, R.id.row7)
private val CK = intArrayOf(R.id.ck0, R.id.ck1, R.id.ck2, R.id.ck3, R.id.ck4, R.id.ck5, R.id.ck6, R.id.ck7)
private val TT = intArrayOf(R.id.tt0, R.id.tt1, R.id.tt2, R.id.tt3, R.id.tt4, R.id.tt5, R.id.tt6, R.id.tt7)
private val DAYV = intArrayOf(R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6)

class Row(val key: String, val title: String, val done: Boolean, val color: Int)
private class Seg(val g: G, val a: Int, val b: Int, val s: Int, val e: Int, var r: Int = 0)
private class Item(val s: Int, val e: Int, val g: G?, val seg: Seg?, val kids: List<Seg>, var row: Int = 0, var h: Float = 0f)

class GoalsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACT) return
        val n = intent.getIntExtra("n", 0)
        val sel = Store.sel(context)
        when (intent.getStringExtra("a")) {
            "wk" -> Store.setSel(context, sel + 7 * n)
            "mo" -> Store.setSel(context, shiftMonth(sel, n))
            "day" -> Store.setSel(context, wsOf(sel) + n)
            "today" -> Store.setSel(context, todayDay())
            "view" -> Store.setView(context, if (Store.view(context) == n) 0 else n)
        }
        refresh(context)
    }

    companion object {
        const val ACT = "app.goals.ACT"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, GoalsWidget::class.java))) update(c, m, id)
        }

        private fun act(c: Context, a: String, n: Int): PendingIntent {
            val i = Intent(c, GoalsWidget::class.java)
            i.action = ACT
            i.data = Uri.parse("goals://act/" + a + "/" + n)
            i.putExtra("a", a)
            i.putExtra("n", n)
            return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun open(c: Context, cls: Class<*>, m: String): PendingIntent {
            val i = Intent(c, cls)
            i.data = Uri.parse("goals://open/" + cls.simpleName + "/" + Uri.encode(m))
            i.putExtra("m", m)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            val o = mgr.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 320).coerceAtLeast(240)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 420).coerceAtLeast(240)
            val m = Model(c)
            val today = todayDay()
            val sel = Store.sel(c)
            val ws = wsOf(sel)
            val tr = Store.tr(c)
            val pal = PalGen.get(c, tr)
            val innerW = (wDp - 24) * d
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setInt(R.id.scrim, "setImageAlpha", ((100 - tr) * 0.8f * 2.55f).toInt())

            // الهيدر
            rv.setImageViewBitmap(R.id.ic_menu, dotsBmp((20 * d).toInt(), pal.fg))
            rv.setImageViewBitmap(R.id.ic_add, plusBmp((24 * d).toInt(), pal.fg))
            rv.setImageViewBitmap(R.id.ic_today, todayBmp((48 * d).toInt(), pal.fg, civil(today)[2]))
            rv.setImageViewBitmap(R.id.wk_prev, chevBmp((56 * d).toInt(), pal.muted, true))
            rv.setImageViewBitmap(R.id.wk_next, chevBmp((56 * d).toInt(), pal.muted, false))
            rv.setImageViewBitmap(R.id.mo_prev, chevBmp((56 * d).toInt(), pal.muted, true))
            rv.setImageViewBitmap(R.id.mo_next, chevBmp((56 * d).toInt(), pal.muted, false))
            val cs = civil(sel)
            rv.setTextViewText(R.id.wk_lbl, weekNo(ws).toString())
            rv.setTextViewText(R.id.mo_lbl, MONTHS[cs[1] - 1] + (if (cs[0] != civil(today)[0]) " " + cs[0] else ""))
            rv.setTextColor(R.id.wk_lbl, pal.fg)
            rv.setTextColor(R.id.mo_lbl, pal.fg)
            rv.setOnClickPendingIntent(R.id.btn_menu, open(c, MenuActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.btn_add, open(c, AddActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.btn_today, act(c, "today", 0))
            rv.setOnClickPendingIntent(R.id.wk_prev, act(c, "wk", -1))
            rv.setOnClickPendingIntent(R.id.wk_next, act(c, "wk", 1))
            rv.setOnClickPendingIntent(R.id.mo_prev, act(c, "mo", -1))
            rv.setOnClickPendingIntent(R.id.mo_next, act(c, "mo", 1))
            rv.setOnClickPendingIntent(R.id.wk_lbl, open(c, PickActivity::class.java, "week"))
            rv.setOnClickPendingIntent(R.id.mo_lbl, open(c, PickActivity::class.java, "month"))

            // الأهداف (أشرطة بدون نص)
            val gb = drawGoals(m, ws, innerW, d, pal, 80f)
            var goalsDp = 0f
            if (gb == null) {
                rv.setViewVisibility(R.id.goals_img, View.GONE)
            } else {
                rv.setViewVisibility(R.id.goals_img, View.VISIBLE)
                rv.setImageViewBitmap(R.id.goals_img, gb)
                rv.setOnClickPendingIntent(R.id.goals_img, open(c, GoalCardActivity::class.java, ""))
                goalsDp = gb.height / d
            }

            // أيام الأسبوع
            rv.setImageViewBitmap(R.id.week_img, drawWeek(m, ws, sel, today, innerW, d, pal))
            for (i in 0..6) rv.setOnClickPendingIntent(DAYV[i], act(c, "day", i))

            // شريط اليوم + المتراكمة + القوائم
            val od = overdueRows(m, today, pal)
            val view = Store.view(c).let { if (it == 1 && od.isEmpty()) 0 else it }
            val dr = dayRows(m, sel, pal)
            val frac = if (dr.isEmpty()) 0f else dr.count { it.done }.toFloat() / dr.size
            rv.setImageViewBitmap(R.id.bar_img, drawTodayBar(frac, od.isNotEmpty(), view, innerW, d, pal))
            rv.setOnClickPendingIntent(R.id.z_list, act(c, "view", 2))
            rv.setOnClickPendingIntent(R.id.z_dot, act(c, "view", 1))

            // المهام
            val rows = when (view) {
                1 -> od
                2 -> listRows(m, pal)
                else -> dr
            }
            val avail = hDp - 24 - 44 - goalsDp - 62 - 32 - 6
            val cap = (avail / 34f).toInt().coerceIn(1, 8)
            val shown = if (rows.size > cap) cap - 1 else rows.size
            for (i in 0..7) {
                if (rows.isEmpty() && i == 0) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.VISIBLE)
                    rv.setImageViewBitmap(CK[i], checkBmp((24 * d).toInt(), PalGen.alpha(pal.fg, 70), true))
                    rv.setTextViewText(TT[i], "")
                } else if (i < shown) {
                    val r = rows[i]
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.VISIBLE)
                    rv.setImageViewBitmap(CK[i], checkBmp((24 * d).toInt(), r.color, r.done))
                    val sp = SpannableString(r.title)
                    if (r.done) sp.setSpan(StrikethroughSpan(), 0, sp.length, 0)
                    rv.setTextViewText(TT[i], sp)
                    rv.setTextColor(TT[i], if (r.done) pal.muted else pal.fg)
                    rv.setOnClickPendingIntent(ROW[i], open(c, CelebrateActivity::class.java, r.key))
                } else if (i == shown && rows.size > shown) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.GONE)
                    rv.setTextViewText(TT[i], "+" + (rows.size - shown))
                    rv.setTextColor(TT[i], pal.muted)
                } else {
                    rv.setViewVisibility(ROW[i], View.GONE)
                }
            }
            mgr.updateAppWidget(id, rv)
        }
    }
}

fun dayRows(m: Model, sel: Int, pal: Pal): List<Row> {
    val out = ArrayList<Row>()
    for (g in m.goals) for (t in g.tasks) if (t.date == sel) out.add(Row("g|" + g.id + "|" + t.id, t.title, t.done, PalGen.goalColor(m, pal, g)))
    for (t in m.loose) if (t.date == sel) out.add(Row("l|" + t.id, t.title, t.done, PalGen.alpha(pal.fg, 200)))
    return out
}

fun overdueRows(m: Model, today: Int, pal: Pal): List<Row> {
    val tmp = ArrayList<Pair<Int, Row>>()
    for (g in m.goals) for (t in g.tasks) if (t.date < today && !t.done) tmp.add(Pair(t.date, Row("g|" + g.id + "|" + t.id, t.title, false, PalGen.goalColor(m, pal, g))))
    for (t in m.loose) if (t.date < today && !t.done) tmp.add(Pair(t.date, Row("l|" + t.id, t.title, false, PalGen.alpha(pal.fg, 200))))
    return tmp.sortedBy { it.first }.map { it.second }
}

fun listRows(m: Model, pal: Pal): List<Row> {
    val out = ArrayList<Row>()
    for (l in m.lists) for (i in l.items) out.add(Row("i|" + l.id + "|" + i.id, i.title, i.done, PalGen.tone(pal, l.id)))
    return out
}

private fun <X> pack(list: List<X>, s: (X) -> Int, e: (X) -> Int, set: (X, Int) -> Unit): Int {
    val ends = ArrayList<Int>()
    for (x in list.sortedWith(compareBy<X>({ s(it) }, { -e(it) }))) {
        var r = ends.indexOfFirst { en -> en < s(x) }
        if (r < 0) {
            ends.add(e(x))
            r = ends.size - 1
        } else ends[r] = e(x)
        set(x, r)
    }
    return ends.size
}

private fun drawGoals(m: Model, ws: Int, W: Float, d: Float, pal: Pal, maxDp: Float): Bitmap? {
    val barH = 12 * d
    val gap = 3 * d
    val colW = W / 7
    fun xl(i: Int): Float = W - (i + 1) * colW
    val segs = m.goals.mapNotNull { g ->
        val a = g.s - ws
        val b = g.e - ws
        if (b < 0 || a > 6) null else Seg(g, a, b, maxOf(a, 0), minOf(b, 6))
    }
    val items = ArrayList<Item>()
    for (g in m.goals.filter { it.long }) {
        val ks = segs.filter { it.g.parent == g.id }
        val ls = segs.firstOrNull { it.g.id == g.id }
        val all = ks + listOfNotNull(ls)
        if (all.isEmpty()) continue
        val rows = pack(ks, { it.s }, { it.e }, { x, r -> x.r = r })
        items.add(Item(all.minOf { it.s }, all.maxOf { it.e }, g, null, ks, h = 8 * d + maxOf(rows, 1) * barH + maxOf(rows - 1, 0) * gap))
    }
    for (sg in segs) {
        if (!sg.g.long && m.byId[sg.g.parent] == null) items.add(Item(sg.s, sg.e, null, sg, emptyList(), h = barH))
    }
    if (items.isEmpty()) return null
    val nrows = pack(items, { it.s }, { it.e }, { x, r -> x.row = r })
    val rowH = FloatArray(nrows)
    for (im in items) rowH[im.row] = maxOf(rowH[im.row], im.h)
    val rowY = FloatArray(nrows)
    var acc = 0f
    for (r in 0 until nrows) {
        rowY[r] = acc
        acc += rowH[r] + gap
    }
    val H = minOf(acc - gap, maxDp * d)
    val bmp = Bitmap.createBitmap(W.toInt(), maxOf(H.toInt(), 1), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    fun drawBar(sg: Seg, top: Float, color: Int) {
        val left = xl(sg.e) + 1
        val w = (sg.e - sg.s + 1) * colW - 2
        val rr = RectF(left, top, left + w, top + barH)
        val p = m.prog(sg.g)
        val f = ((p * (sg.b - sg.a + 1) - (sg.s - sg.a)) / (sg.e - sg.s + 1)).coerceIn(0f, 1f)
        val path = Path().apply { addRoundRect(rr, barH / 2, barH / 2, Path.Direction.CW) }
        cv.save()
        cv.clipPath(path)
        fill.style = Paint.Style.FILL
        fill.color = PalGen.alpha(color, 70)
        cv.drawRect(rr, fill)
        fill.color = color
        cv.drawRect(rr.right - f * w, rr.top, rr.right, rr.bottom, fill)
        cv.restore()
    }
    for (im in items) {
        if (rowY[im.row] + rowH[im.row] > H + 1) continue
        val g = im.g
        if (g != null) {
            val gc = PalGen.tone(pal, g.id)
            val p = m.prog(g)
            val left = xl(im.e) + 1
            val w = (im.e - im.s + 1) * colW - 2
            val top = rowY[im.row]
            val rr = RectF(left, top, left + w, top + im.h)
            fill.style = Paint.Style.FILL
            fill.color = gc
            fill.alpha = (255 * (0.14f + 0.7f * p)).toInt()
            cv.drawRoundRect(rr, 9 * d, 9 * d, fill)
            stroke.color = gc
            stroke.strokeWidth = 1.2f * d
            cv.drawRoundRect(rr, 9 * d, 9 * d, stroke)
            val ks = m.kids(g)
            for (k in im.kids) {
                val sc = when (ks.indexOf(k.g) % 3) {
                    0 -> PalGen.mix(gc, Color.WHITE, 0.4f)
                    1 -> gc
                    else -> PalGen.mix(gc, Color.BLACK, 0.3f)
                }
                drawBar(k, top + 4 * d + k.r * (barH + gap), sc)
            }
        } else {
            val sg = im.seg
            if (sg != null) drawBar(sg, rowY[im.row], PalGen.goalColor(m, pal, sg.g))
        }
    }
    return bmp
}

private fun drawWeek(m: Model, ws: Int, sel: Int, today: Int, W: Float, d: Float, pal: Pal): Bitmap {
    val bmp = Bitmap.createBitmap(W.toInt(), (62 * d).toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val colW = W / 7
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.textAlign = Paint.Align.CENTER
    fun cx(i: Int): Float = W - (i + 0.5f) * colW
    val dots = HashMap<Int, ArrayList<Int>>()
    for (g in m.goals) if (!g.long) for (t in g.tasks) dots.getOrPut(t.date) { ArrayList() }.add(PalGen.goalColor(m, pal, g))
    for (t in m.loose) dots.getOrPut(t.date) { ArrayList() }.add(pal.muted)
    for (i in 0..6) {
        val day = ws + i
        val cy = 36 * d
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT
        p.textSize = 12 * d
        p.color = pal.muted
        cv.drawText(DAYS[i], cx(i), 13 * d, p)
        if (day == sel) {
            p.color = pal.accent
            cv.drawCircle(cx(i), cy, 18 * d, p)
        } else if (day == today) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            p.color = pal.accent
            cv.drawCircle(cx(i), cy, 17 * d, p)
            p.style = Paint.Style.FILL
        }
        p.textSize = 19 * d
        p.color = if (day == sel) (if (pal.dark) Color.parseColor("#0B1020") else Color.WHITE) else pal.fg
        cv.drawText(civil(day)[2].toString(), cx(i), cy + 7 * d, p)
        val ds = dots[day]
        if (ds != null) {
            val n = minOf(ds.size, 3)
            for (j in 0 until n) {
                p.color = ds[j]
                cv.drawCircle(cx(i) + (j - (n - 1) / 2f) * 7 * d, 58 * d, 2.2f * d, p)
            }
        }
    }
    return bmp
}

private fun drawTodayBar(frac: Float, hasOd: Boolean, view: Int, W: Float, d: Float, pal: Pal): Bitmap {
    val H = 32 * d
    val bmp = Bitmap.createBitmap(W.toInt(), H.toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val z = 44 * d
    val cy = H / 2
    // أيقونة القوائم (يمين)
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = 1.7f * d
    p.color = if (view == 2) pal.accent else pal.muted
    val lx = W - z / 2
    for (k in -1..1) {
        val y = cy + k * 5 * d
        cv.drawLine(lx - 1 * d, y, lx + 8 * d, y, p)
        cv.drawPoint(lx - 7 * d, y, p)
    }
    // نقطة المتراكمة (يسار)
    if (hasOd) {
        p.style = Paint.Style.FILL
        p.color = pal.warn
        cv.drawCircle(z / 2, cy, 4.5f * d, p)
        if (view == 1) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            cv.drawCircle(z / 2, cy, 8.5f * d, p)
        }
    }
    // شريط التقدم
    val l = z
    val r = W - z
    p.style = Paint.Style.FILL
    p.color = PalGen.alpha(pal.accent, 70)
    cv.drawRoundRect(RectF(l, cy - 2 * d, r, cy + 2 * d), 2 * d, 2 * d, p)
    p.color = pal.accent
    cv.drawRoundRect(RectF(r - frac * (r - l), cy - 2 * d, r, cy + 2 * d), 2 * d, 2 * d, p)
    return bmp
}

private fun chevBmp(sz: Int, color: Int, right: Boolean): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeJoin = Paint.Join.ROUND
    p.strokeWidth = sz * 0.1f
    val c = sz / 2f
    val s = if (right) 1f else -1f
    val path = Path()
    path.moveTo(c - s * sz * 0.14f, c - sz * 0.26f)
    path.lineTo(c + s * sz * 0.14f, c)
    path.lineTo(c - s * sz * 0.14f, c + sz * 0.26f)
    cv.drawPath(path, p)
    return b
}

private fun todayBmp(sz: Int, color: Int, day: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = sz * 0.085f
    cv.drawRoundRect(RectF(sz * 0.1f, sz * 0.16f, sz * 0.9f, sz * 0.9f), sz * 0.2f, sz * 0.2f, p)
    cv.drawLine(sz * 0.32f, sz * 0.05f, sz * 0.32f, sz * 0.24f, p)
    cv.drawLine(sz * 0.68f, sz * 0.05f, sz * 0.68f, sz * 0.24f, p)
    p.style = Paint.Style.FILL
    p.textAlign = Paint.Align.CENTER
    p.typeface = Typeface.DEFAULT_BOLD
    p.textSize = sz * 0.42f
    cv.drawText(day.toString(), sz / 2f, sz * 0.7f, p)
    return b
}

private fun dotsBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    for (k in -1..1) cv.drawCircle(sz / 2f, sz / 2f + k * sz * 0.28f, sz * 0.09f, p)
    return b
}

private fun plusBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = sz * 0.1f
    val c = sz / 2f
    val r = sz * 0.34f
    cv.drawLine(c - r, c, c + r, c, p)
    cv.drawLine(c, c - r, c, c + r, p)
    return b
}

private fun checkBmp(sz: Int, color: Int, done: Boolean): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = sz / 2f
    val r = sz * 0.36f
    p.color = color
    if (done) {
        cv.drawCircle(c, c, r, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        val ck = Path()
        ck.moveTo(c - sz * 0.15f, c)
        ck.lineTo(c - sz * 0.04f, c + sz * 0.11f)
        ck.lineTo(c + sz * 0.16f, c - sz * 0.1f)
        cv.drawPath(ck, p)
    } else {
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.075f
        cv.drawCircle(c, c, r, p)
    }
    return b
}
