package app.goals

import android.app.PendingIntent
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.SpannableString
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews

private val ROW = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4, R.id.row5, R.id.row6, R.id.row7)
private val CK = intArrayOf(R.id.ck0, R.id.ck1, R.id.ck2, R.id.ck3, R.id.ck4, R.id.ck5, R.id.ck6, R.id.ck7)
private val TT = intArrayOf(R.id.tt0, R.id.tt1, R.id.tt2, R.id.tt3, R.id.tt4, R.id.tt5, R.id.tt6, R.id.tt7)
private val TG = intArrayOf(R.id.tg0, R.id.tg1, R.id.tg2, R.id.tg3, R.id.tg4, R.id.tg5, R.id.tg6, R.id.tg7)
private val DAYV = intArrayOf(R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6)

class Theme(val fg: Int, val muted: Int, val bar: Int)
class Row(val key: String, val title: String, val done: Boolean, val color: Int, val tag: String)
private class Seg(val g: G, val a: Int, val b: Int, val s: Int, val e: Int, var r: Int = 0)
private class Item(val s: Int, val e: Int, val g: G?, val seg: Seg?, val kids: List<Seg>, var row: Int = 0, var h: Float = 0f)

class GoalsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        update(context, appWidgetManager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACT) return
        val n = intent.getIntExtra("n", 0)
        val sel = Store.sel(context)
        when (intent.getStringExtra("a")) {
            "wk" -> Store.setSel(context, sel + 7 * n)
            "mo" -> Store.setSel(context, shiftMonth(sel, n))
            "day" -> Store.setSel(context, wsOf(sel) + n)
            "toggle" -> Store.toggle(context, intent.getStringExtra("k") ?: "")
            "mode" -> Store.setMode(context, (Store.mode(context) + 1) % 3)
        }
        refresh(context)
    }

    companion object {
        const val ACT = "app.goals.ACT"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, GoalsWidget::class.java))) update(c, m, id)
        }

        private fun act(c: Context, a: String, n: Int, k: String = ""): PendingIntent {
            val i = Intent(c, GoalsWidget::class.java)
            i.action = ACT
            i.data = Uri.parse("goals://act/" + a + "/" + n + "/" + Uri.encode(k))
            i.putExtra("a", a)
            i.putExtra("n", n)
            i.putExtra("k", k)
            return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun open(c: Context, cls: Class<*>, m: String): PendingIntent {
            val i = Intent(c, cls)
            i.data = Uri.parse("goals://open/" + cls.simpleName + "/" + m)
            i.putExtra("m", m)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            val o = mgr.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 320).coerceAtLeast(220)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 420).coerceAtLeast(240)
            val m = Model(c)
            val today = todayDay()
            val sel = Store.sel(c)
            val ws = wsOf(sel)
            val tr = Store.tr(c)
            val th = theme(c, tr)
            val innerW = (wDp - 24) * d
            val rv = RemoteViews(c.packageName, R.layout.widget)

            rv.setInt(R.id.scrim, "setImageAlpha", ((100 - tr) * 0.8f * 2.55f).toInt())

            // الهيدر
            rv.setImageViewBitmap(R.id.ic_set, gearBmp((22 * d).toInt(), th.fg))
            rv.setImageViewBitmap(R.id.ic_add, plusBmp((24 * d).toInt(), th.fg))
            val cs = civil(sel)
            rv.setTextViewText(R.id.wk_lbl, "أسبوع " + weekNo(ws))
            rv.setTextViewText(R.id.mo_lbl, MONTHS[cs[1] - 1] + (if (cs[0] != civil(today)[0]) " " + cs[0] else ""))
            for (v in intArrayOf(R.id.wk_lbl, R.id.mo_lbl, R.id.wk_prev, R.id.wk_next, R.id.mo_prev, R.id.mo_next)) rv.setTextColor(v, th.fg)
            rv.setOnClickPendingIntent(R.id.btn_set, open(c, SettingsActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.btn_add, open(c, AddActivity::class.java, ""))
            rv.setOnClickPendingIntent(R.id.wk_prev, act(c, "wk", -1))
            rv.setOnClickPendingIntent(R.id.wk_next, act(c, "wk", 1))
            rv.setOnClickPendingIntent(R.id.mo_prev, act(c, "mo", -1))
            rv.setOnClickPendingIntent(R.id.mo_next, act(c, "mo", 1))
            rv.setOnClickPendingIntent(R.id.wk_lbl, open(c, PickActivity::class.java, "week"))
            rv.setOnClickPendingIntent(R.id.mo_lbl, open(c, PickActivity::class.java, "month"))

            // الأهداف
            val gb = drawGoals(m, ws, innerW, d, th, 80f)
            var goalsDp = 0f
            if (gb == null) {
                rv.setViewVisibility(R.id.goals_img, View.GONE)
            } else {
                rv.setViewVisibility(R.id.goals_img, View.VISIBLE)
                rv.setImageViewBitmap(R.id.goals_img, gb)
                rv.setOnClickPendingIntent(R.id.goals_img, open(c, MainActivity::class.java, ""))
                goalsDp = gb.height / d
            }

            // أيام الأسبوع
            rv.setImageViewBitmap(R.id.week_img, drawWeek(m, ws, sel, today, innerW, d, th))
            for (i in 0..6) rv.setOnClickPendingIntent(DAYV[i], act(c, "day", i))

            // شريط مهام اليوم
            val mode = Store.mode(c)
            val all = buildRows(m, sel, if (mode == 2) 2 else 0)
            val rows = if (mode == 1) buildRows(m, sel, 1) else all
            val label = when (mode) {
                2 -> "القوائم"
                1 -> "المتبقية"
                else -> if (sel == today) "مهام اليوم" else "مهام " + DAYS[Math.floorMod(sel + 5, 7)] + " " + civil(sel)[2]
            }
            val frac = if (all.isEmpty()) 0f else all.count { it.done }.toFloat() / all.size
            rv.setImageViewBitmap(R.id.bar_img, drawTodayBar(label, all.count { it.done }.toString() + "/" + all.size, frac, innerW, d, th))
            rv.setOnClickPendingIntent(R.id.bar_img, act(c, "mode", 0))

            // المهام
            val avail = hDp - 24 - 44 - goalsDp - 62 - 40 - 6
            val cap = (avail / 34f).toInt().coerceIn(1, 8)
            val shown = if (rows.size > cap) cap - 1 else rows.size
            for (i in 0..7) {
                if (rows.isEmpty() && i == 0) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.GONE)
                    rv.setTextViewText(TT[i], if (mode == 2) "لا توجد قوائم، أضف من +" else "لا توجد مهام")
                    rv.setTextColor(TT[i], th.muted)
                    rv.setTextViewText(TG[i], "")
                } else if (i < shown) {
                    val r = rows[i]
                    val color = if (r.color == 0) th.muted else r.color
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.VISIBLE)
                    rv.setImageViewBitmap(CK[i], checkBmp((24 * d).toInt(), color, r.done))
                    val sp = SpannableString(r.title)
                    if (r.done) sp.setSpan(StrikethroughSpan(), 0, sp.length, 0)
                    rv.setTextViewText(TT[i], sp)
                    rv.setTextColor(TT[i], if (r.done) th.muted else th.fg)
                    rv.setTextViewText(TG[i], r.tag)
                    rv.setTextColor(TG[i], th.muted)
                    rv.setOnClickPendingIntent(ROW[i], act(c, "toggle", 0, r.key))
                } else if (i == shown && rows.size > shown) {
                    rv.setViewVisibility(ROW[i], View.VISIBLE)
                    rv.setViewVisibility(CK[i], View.GONE)
                    rv.setTextViewText(TT[i], "+" + (rows.size - shown) + " أخرى (كبّر الودجت)")
                    rv.setTextColor(TT[i], th.muted)
                    rv.setTextViewText(TG[i], "")
                } else {
                    rv.setViewVisibility(ROW[i], View.GONE)
                }
            }
            mgr.updateAppWidget(id, rv)
        }
    }
}

private fun theme(c: Context, tr: Int): Theme {
    var have = false
    var p = 0
    if (Build.VERSION.SDK_INT >= 27) {
        try {
            val wc = WallpaperManager.getInstance(c).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            if (wc != null) {
                p = wc.primaryColor.toArgb()
                have = true
            }
        } catch (e: Exception) {
        }
    }
    val lum = if (have) (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt() else 40
    val scrim = (100 - tr) * 0.8
    val dark = lum * (1 - scrim / 100.0) < 140
    val h = FloatArray(3)
    if (have) Color.colorToHSV(p, h) else {
        h[0] = 222f
        h[1] = 0.6f
        h[2] = 1f
    }
    h[1] = h[1].coerceIn(0.45f, 0.75f)
    h[2] = if (dark) 0.98f else 0.42f
    val fg = if (dark) Color.WHITE else Color.parseColor("#101828")
    val muted = if (dark) Color.argb(170, 255, 255, 255) else Color.argb(150, 16, 24, 40)
    return Theme(fg, muted, Color.HSVToColor(h))
}

private fun buildRows(m: Model, sel: Int, mode: Int): List<Row> {
    val out = ArrayList<Row>()
    if (mode == 2) {
        for (l in m.lists) for (i in l.items) out.add(Row("i|" + l.id + "|" + i.id, i.title, i.done, ACCENT, l.title))
        return out
    }
    for (g in m.goals) for (t in g.tasks) if (t.date == sel && (mode == 0 || !t.done)) out.add(Row("g|" + g.id + "|" + t.id, t.title, t.done, m.col(g), g.title))
    for (t in m.loose) if (t.date == sel && (mode == 0 || !t.done)) out.add(Row("l|" + t.id, t.title, t.done, 0, ""))
    return out
}

private fun <X> pack(list: List<X>, s: (X) -> Int, e: (X) -> Int, set: (X, Int) -> Unit): Int {
    val ends = ArrayList<Int>()
    for (x in list.sortedWith(compareBy<X>({ s(it) }, { -e(it) }))) {
        var r = ends.indexOfFirst { en -> en < s(x) }
        if (r < 0) {
            ends.add(e(x))
            r = ends.size - 1
        } else ends[r] = e(x)
        set(x, r)
    }
    return ends.size
}

private fun mix(a: Int, b: Int, t: Float): Int {
    fun f(x: Int, y: Int) = (x + (y - x) * t).toInt()
    return Color.rgb(f(Color.red(a), Color.red(b)), f(Color.green(a), Color.green(b)), f(Color.blue(a), Color.blue(b)))
}

private fun drawGoals(m: Model, ws: Int, W: Float, d: Float, th: Theme, maxDp: Float): Bitmap? {
    val barH = 14 * d
    val gap = 3 * d
    val colW = W / 7
    fun xl(i: Int): Float = W - (i + 1) * colW
    val segs = m.goals.mapNotNull { g ->
        val a = g.s - ws
        val b = g.e - ws
        if (b < 0 || a > 6) null else Seg(g, a, b, maxOf(a, 0), minOf(b, 6))
    }
    val items = ArrayList<Item>()
    for (g in m.goals.filter { it.long }) {
        val ks = segs.filter { it.g.parent == g.id }
        val ls = segs.firstOrNull { it.g.id == g.id }
        val all = ks + listOfNotNull(ls)
        if (all.isEmpty()) continue
        val rows = pack(ks, { it.s }, { it.e }, { x, r -> x.r = r })
        items.add(Item(all.minOf { it.s }, all.maxOf { it.e }, g, null, ks, h = 18 * d + rows * barH + maxOf(rows - 1, 0) * gap))
    }
    for (sg in segs) {
        if (!sg.g.long && m.byId[sg.g.parent] == null) items.add(Item(sg.s, sg.e, null, sg, emptyList(), h = barH))
    }
    if (items.isEmpty()) return null
    val nrows = pack(items, { it.s }, { it.e }, { x, r -> x.row = r })
    val rowH = FloatArray(nrows)
    for (im in items) rowH[im.row] = maxOf(rowH[im.row], im.h)
    val rowY = FloatArray(nrows)
    var acc = 0f
    for (r in 0 until nrows) {
        rowY[r] = acc
        acc += rowH[r] + gap
    }
    val H = minOf(acc - gap, maxDp * d)
    val bmp = Bitmap.createBitmap(W.toInt(), maxOf(H.toInt(), 1), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    fun text(s: String, x: Float, y: Float, size: Float, color: Int) {
        txt.textSize = size * d
        txt.color = color
        txt.textAlign = Paint.Align.RIGHT
        txt.typeface = Typeface.DEFAULT_BOLD
        cv.drawText(s, x, y, txt)
    }
    fun drawBar(sg: Seg, top: Float, color: Int) {
        val left = xl(sg.e) + 1
        val w = (sg.e - sg.s + 1) * colW - 2
        val rr = RectF(left, top, left + w, top + barH)
        val p = m.prog(sg.g)
        val f = ((p * (sg.b - sg.a + 1) - (sg.s - sg.a)) / (sg.e - sg.s + 1)).coerceIn(0f, 1f)
        val path = Path().apply { addRoundRect(rr, barH / 2, barH / 2, Path.Direction.CW) }
        cv.save()
        cv.clipPath(path)
        fill.style = Paint.Style.FILL
        fill.color = Color.argb(95, 0, 0, 0)
        cv.drawRect(rr, fill)
        fill.color = color
        cv.drawRect(rr.right - f * w, rr.top, rr.right, rr.bottom, fill)
        text(sg.g.title, rr.right - 6 * d, top + barH * 0.72f, 9f, Color.WHITE)
        cv.restore()
    }
    for (im in items) {
        if (rowY[im.row] + rowH[im.row] > H + 1) continue
        val g = im.g
        if (g != null) {
            val p = m.prog(g)
            val left = xl(im.e) + 1
            val w = (im.e - im.s + 1) * colW - 2
            val top = rowY[im.row]
            val rr = RectF(left, top, left + w, top + im.h)
            fill.style = Paint.Style.FILL
            fill.color = g.color
            fill.alpha = (255 * (0.15f + 0.85f * p)).toInt()
            cv.drawRoundRect(rr, 9 * d, 9 * d, fill)
            stroke.color = g.color
            stroke.strokeWidth = 1.2f * d
            cv.drawRoundRect(rr, 9 * d, 9 * d, stroke)
            cv.save()
            cv.clipRect(rr)
            text(g.title + " · " + Math.round(p * 100) + "%", rr.right - 7 * d, top + 11 * d, 9f, if (p > 0.5f) Color.WHITE else th.fg)
            cv.restore()
            val ks = m.kids(g)
            for (k in im.kids) {
                val sc = when (ks.indexOf(k.g) % 3) {
                    0 -> mix(g.color, Color.WHITE, 0.4f)
                    1 -> g.color
                    else -> mix(g.color, Color.BLACK, 0.3f)
                }
                drawBar(k, top + 15 * d + k.r * (barH + gap), sc)
            }
        } else {
            val sg = im.seg
            if (sg != null) drawBar(sg, rowY[im.row], m.col(sg.g))
        }
    }
    return bmp
}

private fun drawWeek(m: Model, ws: Int, sel: Int, today: Int, W: Float, d: Float, th: Theme): Bitmap {
    val bmp = Bitmap.createBitmap(W.toInt(), (62 * d).toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val colW = W / 7
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.textAlign = Paint.Align.CENTER
    fun cx(i: Int): Float = W - (i + 0.5f) * colW
    val dots = HashMap<Int, ArrayList<Int>>()
    for (g in m.goals) if (!g.long) for (t in g.tasks) dots.getOrPut(t.date) { ArrayList() }.add(m.col(g))
    for (t in m.loose) dots.getOrPut(t.date) { ArrayList() }.add(th.muted)
    for (i in 0..6) {
        val day = ws + i
        val cy = 36 * d
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT
        p.textSize = 12 * d
        p.color = th.muted
        cv.drawText(DAYS[i], cx(i), 13 * d, p)
        if (day == sel) {
            p.color = ACCENT
            cv.drawCircle(cx(i), cy, 18 * d, p)
        } else if (day == today) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            p.color = ACCENT
            cv.drawCircle(cx(i), cy, 17 * d, p)
            p.style = Paint.Style.FILL
        }
        p.textSize = 19 * d
        p.color = if (day == sel) Color.WHITE else th.fg
        cv.drawText(civil(day)[2].toString(), cx(i), cy + 7 * d, p)
        val ds = dots[day]
        if (ds != null) {
            val n = minOf(ds.size, 3)
            for (j in 0 until n) {
                p.color = ds[j]
                cv.drawCircle(cx(i) + (j - (n - 1) / 2f) * 7 * d, 58 * d, 2.2f * d, p)
            }
        }
    }
    return bmp
}

private fun drawTodayBar(label: String, count: String, frac: Float, W: Float, d: Float, th: Theme): Bitmap {
    val bmp = Bitmap.createBitmap(W.toInt(), (40 * d).toInt(), Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.typeface = Typeface.DEFAULT_BOLD
    p.textSize = 15 * d
    p.color = th.bar
    p.textAlign = Paint.Align.RIGHT
    cv.drawText(label, W - 2 * d, 19 * d, p)
    p.textAlign = Paint.Align.LEFT
    cv.drawText(count, 2 * d, 19 * d, p)
    val r = RectF(0f, 28 * d, W, 32 * d)
    p.alpha = 70
    cv.drawRoundRect(r, 2 * d, 2 * d, p)
    p.color = th.bar
    cv.drawRoundRect(RectF(W - frac * W, r.top, W, r.bottom), 2 * d, 2 * d, p)
    return bmp
}

private fun gearBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    val c = sz / 2f
    val r = sz * 0.27f
    p.strokeWidth = sz * 0.12f
    cv.drawCircle(c, c, r, p)
    p.strokeWidth = sz * 0.15f
    for (k in 0 until 8) {
        val a = Math.toRadians(k * 45.0)
        val cs = Math.cos(a).toFloat()
        val sn = Math.sin(a).toFloat()
        cv.drawLine(c + (r + sz * 0.1f) * cs, c + (r + sz * 0.1f) * sn, c + (r + sz * 0.19f) * cs, c + (r + sz * 0.19f) * sn, p)
    }
    return b
}

private fun plusBmp(sz: Int, color: Int): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.style = Paint.Style.STROKE
    p.strokeCap = Paint.Cap.ROUND
    p.strokeWidth = sz * 0.11f
    val c = sz / 2f
    val r = sz * 0.34f
    cv.drawLine(c - r, c, c + r, c, p)
    cv.drawLine(c, c - r, c, c + r, p)
    return b
}

private fun checkBmp(sz: Int, color: Int, done: Boolean): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val cv = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = sz / 2f
    val r = sz * 0.36f
    p.color = color
    if (done) {
        cv.drawCircle(c, c, r, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        val ck = Path()
        ck.moveTo(c - sz * 0.15f, c)
        ck.lineTo(c - sz * 0.04f, c + sz * 0.11f)
        ck.lineTo(c + sz * 0.16f, c - sz * 0.1f)
        cv.drawPath(ck, p)
    } else {
        p.style = Paint.Style.STROKE
        p.strokeWidth = sz * 0.075f
        cv.drawCircle(c, c, r, p)
    }
    return b
}
