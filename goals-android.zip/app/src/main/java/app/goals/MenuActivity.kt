package app.goals

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.LinearLayout

class MenuActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        fun dp(v: Int): Int = Ui.dp(this, v)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(8), dp(8), dp(8), dp(8))
        fun item(t: String, f: () -> Unit) {
            val v = Ui.tv(this, t, 16f, pal.fg)
            v.setPadding(dp(16), dp(14), dp(16), dp(14))
            v.setOnClickListener {
                f()
                finish()
            }
            root.addView(v, Ui.lp(Ui.MP, Ui.WC))
        }
        item("الإعدادات") { startActivity(Intent(this, SettingsActivity::class.java)) }
        item("فتح التطبيق") { startActivity(Intent(this, MainActivity::class.java)) }
        setContentView(root)
        Glass.apply(this, pal, 0.55f)
        window.setGravity(Gravity.TOP or Gravity.START)
        window.setDimAmount(0.12f)
        val lp = window.attributes
        lp.x = dp(14)
        lp.y = dp(90)
        window.attributes = lp
    }
}
