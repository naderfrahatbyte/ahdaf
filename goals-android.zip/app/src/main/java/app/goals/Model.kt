package app.goals

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

val MONTHS = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
val DAYS = arrayOf("سبت", "أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة")

fun ymd(y0: Int, m: Int, d: Int): Int {
    val y = if (m <= 2) y0 - 1 else y0
    val era = Math.floorDiv(y, 400)
    val yoe = y - era * 400
    val doy = (153 * (if (m > 2) m - 3 else m + 9) + 2) / 5 + d - 1
    val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
    return era * 146097 + doe - 719468
}

fun civil(z0: Int): IntArray {
    val z = z0 + 719468
    val era = Math.floorDiv(z, 146097)
    val doe = z - era * 146097
    val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
    val y = yoe + era * 400
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp = (5 * doy + 2) / 153
    val d = doy - (153 * mp + 2) / 5 + 1
    val m = if (mp < 10) mp + 3 else mp - 9
    return intArrayOf(if (m <= 2) y + 1 else y, m, d)
}

fun days(s: String): Int {
    val p = s.split("-")
    return ymd(p[0].toInt(), p[1].toInt(), p[2].toInt())
}

fun dateStr(day: Int): String {
    val c = civil(day)
    return String.format(Locale.US, "%04d-%02d-%02d", c[0], c[1], c[2])
}

fun todayDay(): Int {
    val c = Calendar.getInstance()
    return ymd(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun wsOf(day: Int): Int = day - Math.floorMod(day + 5, 7)
fun weekYear(ws: Int): Int = civil(ws + 3)[0]
fun firstWeek(y: Int): Int {
    val w = wsOf(ymd(y, 1, 1))
    return if (civil(w + 3)[0] == y) w else w + 7
}
fun weekNo(ws: Int): Int = (ws - firstWeek(weekYear(ws))) / 7 + 1

fun shiftMonth(day: Int, n: Int): Int {
    val c = civil(day)
    val t = c[1] - 1 + n
    val y = c[0] + Math.floorDiv(t, 12)
    val m = Math.floorMod(t, 12) + 1
    val first = ymd(y, m, 1)
    val next = if (m == 12) ymd(y + 1, 1, 1) else ymd(y, m + 1, 1)
    return first + minOf(c[2], next - first) - 1
}

class Tk(val id: String, val title: String, val date: Int, val done: Boolean)
class G(val id: String, val title: String, val color: Int, val s: Int, val e: Int, val long: Boolean, val parent: String, val tasks: List<Tk>)
class LI(val id: String, val title: String, val done: Boolean)
class L(val id: String, val title: String, val items: List<LI>)

class Model(c: Context) {
    val goals = ArrayList<G>()
    val loose = ArrayList<Tk>()
    val lists = ArrayList<L>()
    val byId: Map<String, G>

    init {
        val root = Store.data(c)
        val ga = root.optJSONArray("goals") ?: JSONArray()
        for (i in 0 until ga.length()) {
            val o = ga.optJSONObject(i) ?: continue
            try {
                val ts = ArrayList<Tk>()
                val ta = o.optJSONArray("tasks") ?: JSONArray()
                for (j in 0 until ta.length()) {
                    val t = ta.optJSONObject(j) ?: continue
                    ts.add(Tk(t.optString("id"), t.optString("title"), days(t.getString("date")), t.optBoolean("done")))
                }
                goals.add(G(o.getString("id"), o.optString("title"), Color.parseColor(o.optString("color", "#4a7bff")), days(o.getString("start")), days(o.getString("end")), o.optBoolean("long"), o.optString("parent"), ts))
            } catch (e: Exception) {
            }
        }
        val la = root.optJSONArray("loose") ?: JSONArray()
        for (i in 0 until la.length()) {
            val t = la.optJSONObject(i) ?: continue
            try {
                loose.add(Tk(t.optString("id"), t.optString("title"), days(t.getString("date")), t.optBoolean("done")))
            } catch (e: Exception) {
            }
        }
        val sa = root.optJSONArray("lists") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val o = sa.optJSONObject(i) ?: continue
            val its = ArrayList<LI>()
            val ia = o.optJSONArray("items") ?: JSONArray()
            for (j in 0 until ia.length()) {
                val t = ia.optJSONObject(j) ?: continue
                its.add(LI(t.optString("id"), t.optString("title"), t.optBoolean("done")))
            }
            lists.add(L(o.optString("id"), o.optString("title"), its))
        }
        byId = goals.associateBy { it.id }
    }

    fun col(g: G): Int = byId[g.parent]?.color ?: g.color
    fun kids(g: G): List<G> = goals.filter { it.parent == g.id }
    fun prog(g: G): Float {
        val ts = if (g.long) kids(g).flatMap { it.tasks } else g.tasks
        return if (ts.isEmpty()) 0f else ts.count { it.done }.toFloat() / ts.size
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("g", 0)

    fun data(c: Context): JSONObject = try {
        JSONObject(p(c).getString("d", "") ?: "")
    } catch (e: Exception) {
        JSONObject()
    }

    fun save(c: Context, o: JSONObject) {
        p(c).edit().putString("d", o.toString()).apply()
    }

    fun sel(c: Context): Int {
        val t = todayDay()
        return if (p(c).getInt("selOn", 0) == t) p(c).getInt("sel", t) else t
    }

    fun setSel(c: Context, v: Int) {
        p(c).edit().putInt("sel", v).putInt("selOn", todayDay()).apply()
    }

    fun tr(c: Context): Int = p(c).getInt("tr", 85)
    fun setTr(c: Context, v: Int) {
        p(c).edit().putInt("tr", v).apply()
    }

    fun view(c: Context): Int = p(c).getInt("view", 0)
    fun setView(c: Context, v: Int) {
        p(c).edit().putInt("view", v).apply()
    }

    fun flag(c: Context, k: String): Boolean = p(c).getBoolean(k, true)
    fun setFlag(c: Context, k: String, v: Boolean) {
        p(c).edit().putBoolean(k, v).apply()
    }

    fun uid(): String = java.lang.Long.toString(System.nanoTime(), 36).takeLast(7)

    private fun find(a: JSONArray?, id: String): JSONObject? {
        if (a == null) return null
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i)
            if (o != null && o.optString("id") == id) return o
        }
        return null
    }

    private fun arr(o: JSONObject, k: String): JSONArray {
        var a = o.optJSONArray(k)
        if (a == null) {
            a = JSONArray()
            o.put(k, a)
        }
        return a
    }

    fun toggle(c: Context, key: String): Boolean {
        val o = data(c)
        val parts = key.split("|")
        var res = false
        try {
            val t = when (parts[0]) {
                "g" -> find(find(o.optJSONArray("goals"), parts[1])?.optJSONArray("tasks"), parts[2])
                "l" -> find(o.optJSONArray("loose"), parts[1])
                "i" -> find(find(o.optJSONArray("lists"), parts[1])?.optJSONArray("items"), parts[2])
                else -> null
            }
            if (t != null) {
                res = !t.optBoolean("done")
                t.put("done", res)
            }
        } catch (e: Exception) {
        }
        save(c, o)
        return res
    }

    fun addLoose(c: Context, title: String, date: String, desc: String = "") {
        val o = data(c)
        arr(o, "loose").put(JSONObject().put("id", uid()).put("title", title).put("date", date).put("desc", desc).put("done", false))
        save(c, o)
    }

    fun addGoalTask(c: Context, gid: String, title: String, date: String, desc: String = "") {
        val o = data(c)
        val g = find(o.optJSONArray("goals"), gid) ?: return
        arr(g, "tasks").put(JSONObject().put("id", uid()).put("title", title).put("date", date).put("desc", desc).put("done", false))
        save(c, o)
    }

    fun addList(c: Context, title: String): String {
        val o = data(c)
        val id = uid()
        arr(o, "lists").put(JSONObject().put("id", id).put("title", title).put("items", JSONArray()))
        save(c, o)
        return id
    }

    fun addListItem(c: Context, lid: String, title: String) {
        val o = data(c)
        val l = find(o.optJSONArray("lists"), lid) ?: return
        arr(l, "items").put(JSONObject().put("id", uid()).put("title", title).put("done", false))
        save(c, o)
    }
}
