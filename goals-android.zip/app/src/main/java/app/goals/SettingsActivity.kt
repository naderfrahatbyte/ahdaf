package app.goals

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val d = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setPadding(dp(18), dp(16), dp(18), dp(16))

        val head = TextView(this)
        head.text = "الإعدادات"
        head.textSize = 19f
        head.setTextColor(Color.WHITE)
        head.typeface = Typeface.DEFAULT_BOLD
        root.addView(head)

        val lbl = TextView(this)
        lbl.textSize = 15f
        lbl.setTextColor(Color.WHITE)
        val lpL = LinearLayout.LayoutParams(mp, wc)
        lpL.topMargin = dp(14)
        root.addView(lbl, lpL)
        lbl.text = "شفافية الودجت: " + Store.tr(this) + "%"

        val bar = SeekBar(this)
        bar.max = 100
        bar.progress = Store.tr(this)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                lbl.text = "شفافية الودجت: " + progress + "%"
                Store.setTr(this@SettingsActivity, progress)
                GoalsWidget.refresh(this@SettingsActivity)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(bar, LinearLayout.LayoutParams(mp, wc))

        val hint = TextView(this)
        hint.text = "100% = شفافة تمامًا. الألوان تتكيّف مع خلفية الشاشة تلقائيًا."
        hint.textSize = 12f
        hint.setTextColor(Color.argb(170, 255, 255, 255))
        root.addView(hint)

        val ok = Button(this)
        ok.text = "تم"
        ok.setOnClickListener { finish() }
        val lpB = LinearLayout.LayoutParams(mp, wc)
        lpB.topMargin = dp(12)
        root.addView(ok, lpB)

        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#0d1a45"))
        bg.cornerRadius = 22 * d
        window.setBackgroundDrawable(bg)
        setContentView(root)
        window.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        window.setGravity(Gravity.BOTTOM)
        window.setDimAmount(0f)
    }
}
