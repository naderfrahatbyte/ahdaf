package app.goals

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class PickActivity : Activity() {
    private var year = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pal = PalGen.get(this, 85)
        val week = intent.getStringExtra("m") != "month"
        fun dp(v: Int): Int = Ui.dp(this, v)
        val sel = Store.sel(this)
        val today = todayDay()
        year = if (week) weekYear(wsOf(sel)) else civil(sel)[0]

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = Lang.dir
        root.setPadding(dp(14), dp(14), dp(14), dp(10))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val yearTv = Ui.tv(this, "", 22f, pal.fg, true)
        yearTv.gravity = Gravity.CENTER
        val lv = ListView(this)
        lv.divider = null

        fun chip(t: String, size: Float, f: () -> Unit): TextView {
            val v = Ui.tv(this, t, size, pal.fg)
            v.gravity = Gravity.CENTER
            v.setPadding(dp(14), dp(8), dp(14), dp(8))
            v.setOnClickListener { f() }
            return v
        }

        fun build() {
            yearTv.text = year.toString()
            val labels = ArrayList<String>()
            val starts = ArrayList<Int>()
            val cur = ArrayList<Boolean>()
            val sl = ArrayList<Boolean>()
            val ct = civil(today)
            val cs = civil(sel)
            if (week) {
                var ws = firstWeek(year)
                var n = 1
                while (weekYear(ws) == year) {
                    val a = civil(ws)
                    val b = civil(ws + 6)
                    labels.add(n.toString() + "     " + a[2] + " " + MONTHS[a[1] - 1] + " – " + b[2] + " " + MONTHS[b[1] - 1])
                    starts.add(ws)
                    cur.add(today >= ws && today <= ws + 6)
                    sl.add(sel >= ws && sel <= ws + 6)
                    ws += 7
                    n++
                }
            } else {
                for (mo in 1..12) {
                    labels.add(MONTHS[mo - 1])
                    starts.add(ymd(year, mo, 1))
                    cur.add(ct[0] == year && ct[1] == mo)
                    sl.add(cs[0] == year && cs[1] == mo)
                }
            }
            var focus = 0
            for (i in labels.indices) if (sl[i]) focus = i
            val act = this@PickActivity
            lv.adapter = object : ArrayAdapter<String>(act, android.R.layout.simple_list_item_1, labels) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent) as TextView
                    v.textSize = 16f
                    v.setTextColor(pal.fg)
                    v.gravity = Gravity.CENTER_VERTICAL or Gravity.START
                    v.typeface = if (cur[position]) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    v.setPadding(dp(14), 0, dp(14), 0)
                    v.background = Ui.shape(if (cur[position]) PalGen.alpha(pal.accent, 70) else if (sl[position]) PalGen.alpha(pal.fg, 28) else Color.TRANSPARENT, 0, dp(12).toFloat())
                    return v
                }
            }
            lv.setSelection(focus)
            lv.setOnItemClickListener { _, _, pos, _ ->
                val s0 = starts[pos]
                val target = if (week) {
                    if (today >= s0 && today <= s0 + 6) today else s0
                } else {
                    if (ct[0] == year && ct[1] == pos + 1) today else s0
                }
                Store.setSel(act, target)
                GoalsWidget.refresh(act)
                finish()
            }
        }

        top.addView(chip(if (Lang.en) "‹" else "›", 24f) {
            year--
            build()
        })
        top.addView(yearTv, LinearLayout.LayoutParams(0, Ui.WC, 1f))
        top.addView(chip(if (Lang.en) "›" else "‹", 24f) {
            year++
            build()
        })
        top.addView(chip(T("اليوم", "Today"), 15f) {
            Store.setSel(this, today)
            GoalsWidget.refresh(this)
            finish()
        })
        root.addView(top, Ui.lp(Ui.MP, Ui.WC))
        root.addView(lv, Ui.lp(Ui.MP, (resources.displayMetrics.heightPixels * 0.5f).toInt()))
        build()
        setContentView(root)
        Glass.apply(this, pal)
    }
}
